import { NextRequest, NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "edge";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      dealName,
      codeName,
      intake,
      cascade, // pre-computed cascade result from client
    } = body;

    if (!dealName || !intake?.deal_structure || !intake?.integration_model || !intake?.target_close_date || !intake?.tsa_required) {
      return NextResponse.json({ error: "Missing required fields (Tier 1 gate fields)" }, { status: 400 });
    }

    // 1. Get org (use first org for v0)
    const orgs = await query(`SELECT id FROM organizations LIMIT 1`);
    if (!orgs.length) {
      return NextResponse.json({ error: "No organization found. Run db:seed first." }, { status: 500 });
    }
    const orgId = (orgs[0] as any).id;

    // 2. Create deal
    const deals = await query(
      `INSERT INTO deals (org_id, name, code_name, stage)
       VALUES ($1, $2, $3, 'stage_1_intake')
       RETURNING id`,
      [orgId, dealName, codeName || null]
    );
    const dealId = (deals[0] as any).id;

    // 3. Save intake
    await query(
      `INSERT INTO deal_intake (
        deal_id, deal_structure, integration_model, target_close_date,
        cross_border, cross_border_jurisdictions, tsa_required,
        industry_sector, shared_services_transfer, deal_value_range,
        target_legal_entities, target_gaap_framework, target_erp_system,
        buyer_ma_maturity, tier_1_complete, tier_2_complete, tier_3_complete,
        intake_payload, workstream_activation
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19
      )`,
      [
        dealId,
        intake.deal_structure,
        intake.integration_model,
        intake.target_close_date,
        intake.cross_border || false,
        intake.cross_border_jurisdictions || [],
        intake.tsa_required,
        intake.industry_sector || null,
        intake.shared_services_transfer || [],
        intake.deal_value_range || null,
        intake.target_legal_entities || null,
        intake.target_gaap_framework || null,
        intake.target_erp_system || null,
        intake.buyer_ma_maturity || null,
        cascade?.tier1Complete || false,
        cascade?.tier2Complete || false,
        cascade?.tier3Complete || false,
        JSON.stringify(intake),
        JSON.stringify(cascade?.workstreams?.reduce((acc: any, ws: any) => {
          acc[ws.workstream] = ws.scope;
          return acc;
        }, {}) || {}),
      ]
    );

    // 4. Create workstream configs from cascade
    if (cascade?.workstreams) {
      for (const ws of cascade.workstreams) {
        await query(
          `INSERT INTO deal_workstream_config (deal_id, workstream, scope, total_items, active_items)
           VALUES ($1, $2, $3, $4, $4)
           ON CONFLICT (deal_id, workstream) DO UPDATE SET scope = $3, total_items = $4, active_items = $4`,
          [dealId, ws.workstream, ws.scope, ws.itemCount]
        );
      }
    }

    // 5. Create milestones from cascade
    if (cascade?.milestones) {
      for (const ms of cascade.milestones) {
        await query(
          `INSERT INTO deal_milestones (deal_id, phase, label, target_date, status)
           VALUES ($1, $2, $3, $4, 'upcoming')
           ON CONFLICT (deal_id, phase) DO NOTHING`,
          [dealId, ms.phase, ms.label, ms.date]
        );
      }
    }

    // 6. Instantiate checklist items from master taxonomy
    // Get all master items
    const masterItems = await query(
      `SELECT * FROM taxonomy_activities_master ORDER BY item_id`
    );

    // Build scope lookup
    const scopeLookup: Record<string, string> = {};
    if (cascade?.workstreams) {
      for (const ws of cascade.workstreams) {
        scopeLookup[ws.workstream] = ws.scope;
      }
    }

    let instantiated = 0;
    for (const item of masterItems as any[]) {
      const wsScope = scopeLookup[item.workstream] || "full_scope";

      // Skip N/A workstreams
      if (wsScope === "not_applicable") continue;

      // Calculate milestone date from close date
      const closeDate = new Date(intake.target_close_date);
      const phaseOffsets: Record<string, number> = {
        pre_close: -14, day_1: 0, day_30: 30, day_60: 60, day_90: 90, day_180: 180, year_1: 365,
      };
      const offset = phaseOffsets[item.default_phase] ?? 0;
      const milestoneDate = new Date(closeDate);
      milestoneDate.setDate(milestoneDate.getDate() + offset);

      // Cross-border flag
      const cbFlag = item.cross_border_relevant && intake.cross_border;

      await query(
        `INSERT INTO deal_checklist_items (
          deal_id, source_item_id, workstream, section, description,
          status, phase, priority, milestone_date,
          is_active, scope, tsa_relevant, cross_border_flag,
          guidance_prompt, source, source_version
        ) VALUES (
          $1, $2, $3, $4, $5, 'not_started', $6, $7, $8, true, $9, $10, $11, $12, 'master', '1.0'
        )`,
        [
          dealId, item.item_id, item.workstream, item.section, item.description,
          item.default_phase, item.default_priority, milestoneDate.toISOString().split("T")[0],
          wsScope, item.tsa_relevant || false, cbFlag || false,
          item.guidance_prompt || null,
        ]
      );
      instantiated++;
    }

    // 7. Create initial risk register from auto-detected risks
    if (cascade?.riskFlags) {
      for (const risk of cascade.riskFlags) {
        await query(
          `INSERT INTO deal_risk_register (deal_id, category, description, severity, mitigation_status)
           VALUES ($1, $2, $3, $4, 'open')`,
          [dealId, risk.category, risk.description, risk.severity]
        );
      }
    }

    // 8. Log to audit trail
    await query(
      `INSERT INTO audit_log (deal_id, entity_type, entity_id, action, new_state, metadata)
       VALUES ($1, 'deal', $2, 'created', $3, $4)`,
      [
        dealId, dealId,
        JSON.stringify({ stage: "stage_1_intake" }),
        JSON.stringify({ items_instantiated: instantiated, risks_created: cascade?.riskFlags?.length || 0 }),
      ]
    );

    // 9. Advance to Stage 2
    await query(
      `UPDATE deals SET stage = 'stage_2_review_assign', updated_at = NOW() WHERE id = $1`,
      [dealId]
    );

    return NextResponse.json({
      dealId,
      itemsInstantiated: instantiated,
      risksCreated: cascade?.riskFlags?.length || 0,
      workstreamsConfigured: cascade?.workstreams?.length || 0,
    });
  } catch (error) {
    console.error("Intake API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
