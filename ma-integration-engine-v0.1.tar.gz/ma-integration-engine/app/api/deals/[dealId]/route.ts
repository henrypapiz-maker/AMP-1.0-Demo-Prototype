import { NextRequest, NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "edge";

export async function GET(
  _req: NextRequest,
  { params }: { params: { dealId: string } }
) {
  try {
    const { dealId } = params;

    const deals = await query(
      `SELECT d.*, di.deal_structure, di.integration_model, di.target_close_date,
              di.cross_border, di.cross_border_jurisdictions, di.tsa_required,
              di.industry_sector, di.deal_value_range, di.target_legal_entities,
              di.target_gaap_framework, di.buyer_ma_maturity
       FROM deals d LEFT JOIN deal_intake di ON d.id = di.deal_id
       WHERE d.id = $1`,
      [dealId]
    );

    if (!deals.length) {
      return NextResponse.json({ error: "Deal not found" }, { status: 404 });
    }

    const progress = await query(
      `SELECT workstream,
              COUNT(*) FILTER (WHERE is_active) AS total_items,
              COUNT(*) FILTER (WHERE status = 'complete' AND is_active) AS complete,
              COUNT(*) FILTER (WHERE status = 'in_progress' AND is_active) AS in_progress,
              COUNT(*) FILTER (WHERE status = 'blocked' AND is_active) AS blocked,
              COUNT(*) FILTER (WHERE status = 'not_started' AND is_active) AS not_started,
              ROUND(COUNT(*) FILTER (WHERE status = 'complete' AND is_active)::NUMERIC /
                NULLIF(COUNT(*) FILTER (WHERE is_active), 0) * 100, 1) AS completion_pct
       FROM deal_checklist_items WHERE deal_id = $1
       GROUP BY workstream ORDER BY workstream`,
      [dealId]
    );

    const [stats] = await query(
      `SELECT COUNT(*) FILTER (WHERE is_active) AS total,
              COUNT(*) FILTER (WHERE status = 'complete' AND is_active) AS complete,
              COUNT(*) FILTER (WHERE status = 'in_progress' AND is_active) AS in_progress,
              COUNT(*) FILTER (WHERE status = 'blocked' AND is_active) AS blocked,
              COUNT(*) FILTER (WHERE status = 'not_started' AND is_active) AS not_started
       FROM deal_checklist_items WHERE deal_id = $1`,
      [dealId]
    );

    const risks = await query(
      `SELECT * FROM deal_risk_register WHERE deal_id = $1 AND severity != 'resolved'
       ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END`,
      [dealId]
    );

    const milestones = await query(
      `SELECT * FROM deal_milestones WHERE deal_id = $1 ORDER BY target_date`, [dealId]
    );

    return NextResponse.json({ deal: deals[0], progress, stats, risks, milestones });
  } catch (error) {
    console.error("Deal dashboard API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
