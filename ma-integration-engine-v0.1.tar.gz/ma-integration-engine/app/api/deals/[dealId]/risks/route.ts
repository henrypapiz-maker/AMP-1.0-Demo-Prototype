import { NextRequest, NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "edge";

export async function GET(
  _req: NextRequest,
  { params }: { params: { dealId: string } }
) {
  try {
    const risks = await query(
      `SELECT r.*, COUNT(dci.id) AS related_item_count
       FROM deal_risk_register r
       LEFT JOIN deal_checklist_items dci
         ON r.deal_id = dci.deal_id AND dci.workstream = r.related_workstream AND dci.is_active = true
       WHERE r.deal_id = $1
       GROUP BY r.id
       ORDER BY CASE r.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END`,
      [params.dealId]
    );
    return NextResponse.json({ risks });
  } catch (error) {
    console.error("Risks API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
