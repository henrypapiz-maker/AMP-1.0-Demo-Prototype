import { NextRequest, NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "edge";

export async function GET(
  req: NextRequest,
  { params }: { params: { dealId: string } }
) {
  try {
    const { dealId } = params;
    const url = new URL(req.url);
    const workstream = url.searchParams.get("workstream");
    const status = url.searchParams.get("status");
    const phase = url.searchParams.get("phase");
    const priority = url.searchParams.get("priority");
    const search = url.searchParams.get("q");

    let sql = `SELECT * FROM deal_checklist_items WHERE deal_id = $1 AND is_active = true`;
    const sqlParams: unknown[] = [dealId];
    let paramIdx = 2;

    if (workstream) {
      sql += ` AND workstream = $${paramIdx++}`;
      sqlParams.push(workstream);
    }
    if (status) {
      sql += ` AND status = $${paramIdx++}`;
      sqlParams.push(status);
    }
    if (phase) {
      sql += ` AND phase = $${paramIdx++}`;
      sqlParams.push(phase);
    }
    if (priority) {
      sql += ` AND priority = $${paramIdx++}`;
      sqlParams.push(priority);
    }
    if (search) {
      sql += ` AND (description ILIKE $${paramIdx} OR section ILIKE $${paramIdx})`;
      sqlParams.push(`%${search}%`);
      paramIdx++;
    }

    sql += ` ORDER BY
      CASE priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      CASE phase WHEN 'pre_close' THEN 1 WHEN 'day_1' THEN 2 WHEN 'day_30' THEN 3 WHEN 'day_60' THEN 4 WHEN 'day_90' THEN 5 ELSE 6 END,
      workstream, section`;

    const items = await query(sql, sqlParams);
    return NextResponse.json({ items, count: items.length });
  } catch (error) {
    console.error("Checklist API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// Update checklist item status
export async function PATCH(
  req: NextRequest,
  { params }: { params: { dealId: string } }
) {
  try {
    const { dealId } = params;
    const body = await req.json();
    const { itemId, status, notes, blocked_reason } = body;

    if (!itemId || !status) {
      return NextResponse.json({ error: "itemId and status required" }, { status: 400 });
    }

    const now = new Date().toISOString();
    let extraFields = "";
    const sqlParams: unknown[] = [status, now, itemId, dealId];
    let paramIdx = 5;

    if (status === "in_progress") {
      extraFields += `, started_at = COALESCE(started_at, $${paramIdx++})`;
      sqlParams.push(now);
    }
    if (status === "complete") {
      extraFields += `, completed_at = $${paramIdx++}`;
      sqlParams.push(now);
    }
    if (status === "blocked" && blocked_reason) {
      extraFields += `, blocked_at = $${paramIdx++}, blocked_reason = $${paramIdx++}`;
      sqlParams.push(now, blocked_reason);
    }

    const result = await query(
      `UPDATE deal_checklist_items
       SET status = $1, last_status_change = $2, updated_at = $2 ${extraFields}
       WHERE id = $3 AND deal_id = $4
       RETURNING *`,
      sqlParams
    );

    if (!result.length) {
      return NextResponse.json({ error: "Item not found" }, { status: 404 });
    }

    // Log to audit trail
    await query(
      `INSERT INTO audit_log (deal_id, entity_type, entity_id, action, new_state, metadata)
       VALUES ($1, 'checklist_item', $2, 'status_change', $3, $4)`,
      [dealId, itemId, JSON.stringify({ status }), JSON.stringify({ notes: notes || null })]
    );

    return NextResponse.json({ item: result[0] });
  } catch (error) {
    console.error("Checklist update error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
