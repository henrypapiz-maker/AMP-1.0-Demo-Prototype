import { NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "edge";

export async function GET() {
  try {
    const deals = await query(
      `SELECT d.*,
              di.deal_structure, di.integration_model, di.target_close_date,
              di.cross_border, di.tsa_required, di.industry_sector,
              di.deal_value_range, di.tier_1_complete
       FROM deals d
       LEFT JOIN deal_intake di ON d.id = di.deal_id
       WHERE d.is_active = true
       ORDER BY d.created_at DESC`
    );
    return NextResponse.json({ deals });
  } catch (error) {
    console.error("Deals API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
