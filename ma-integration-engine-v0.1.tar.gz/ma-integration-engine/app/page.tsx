"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { DEAL_STRUCTURE_LABELS, STAGE_LABELS } from "@/lib/types";

// Demo fallback data for when DB isn't connected yet
const DEMO_DEALS = [
  {
    id: "demo",
    name: "Meridian Acquisition",
    code_name: "Project Meridian",
    stage: "stage_3_execute_track",
    deal_structure: "merger_reverse_triangular",
    target_close_date: "2026-04-15",
    cross_border: true,
    industry_sector: "Technology",
    deal_value_range: "$1B–$5B",
  },
];

export default function HomePage() {
  const [deals, setDeals] = useState<any[]>(DEMO_DEALS);
  const [loading, setLoading] = useState(true);
  const [dbConnected, setDbConnected] = useState(false);

  useEffect(() => {
    fetch("/api/deals")
      .then((r) => r.json())
      .then((data) => {
        if (data.deals?.length) {
          setDeals(data.deals);
          setDbConnected(true);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const daysToClose = (dateStr: string) => {
    const d = new Date(dateStr);
    const now = new Date();
    return Math.ceil((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="min-h-screen bg-[#0C1220] flex flex-col">
      {/* Header */}
      <header className="border-b border-[#1E293B] px-8 py-6">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/80 to-amber-700/80 flex items-center justify-center text-white font-bold text-base tracking-tight shadow-lg shadow-amber-900/20">
              M&A
            </div>
            <div>
              <h1 className="text-lg font-semibold text-white tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
                Integration Engine
              </h1>
              <p className="text-[11px] text-slate-500 uppercase tracking-widest">
                Finance & Accounting · v0.1 Pre-Demo
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {!dbConnected && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-400 text-[11px] font-medium border border-amber-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                Demo Mode — Connect Neon for live data
              </span>
            )}
            {dbConnected && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-[11px] font-medium border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Connected to Neon
              </span>
            )}
            <Link
              href="/intake"
              className="px-4 py-2 rounded-lg text-sm font-semibold bg-gradient-to-r from-amber-600 to-amber-700 text-white hover:from-amber-500 hover:to-amber-600 shadow-lg shadow-amber-900/20 transition-all"
            >
              + New Deal
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-8 py-10">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "var(--font-display)" }}>
              Active Deals
            </h2>
            <p className="text-sm text-slate-400">
              Select a deal to access the integration dashboard, checklist, and risk register.
            </p>
          </div>

          {/* Deal Cards */}
          <div className="grid gap-4">
            {deals.map((deal, i) => (
              <Link
                key={deal.id}
                href={`/deal/${deal.id}`}
                className="group block"
              >
                <div className="card hover:border-amber-500/30 transition-all duration-200 hover:shadow-lg hover:shadow-amber-900/5">
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="text-lg font-semibold text-white group-hover:text-amber-200 transition-colors">
                            {deal.code_name || deal.name}
                          </h3>
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold text-amber-400 bg-amber-500/10 uppercase tracking-wider">
                            {deal.stage?.replace("stage_", "S").replace("_", " ").split(" ")[0]}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">
                          {STAGE_LABELS[deal.stage as keyof typeof STAGE_LABELS] || deal.stage}
                        </p>
                      </div>
                      {deal.target_close_date && (
                        <div className="text-right">
                          <div className="text-2xl font-bold text-white tabular-nums">
                            {daysToClose(deal.target_close_date)}
                          </div>
                          <div className="text-[10px] text-slate-500 uppercase tracking-wider">Days to close</div>
                        </div>
                      )}
                    </div>

                    {/* Deal attributes */}
                    <div className="flex flex-wrap gap-3 text-xs text-slate-400">
                      {deal.deal_structure && (
                        <span className="flex items-center gap-1.5">
                          <span className="text-slate-600">Structure:</span>
                          <span className="text-slate-300">
                            {DEAL_STRUCTURE_LABELS[deal.deal_structure as keyof typeof DEAL_STRUCTURE_LABELS] || deal.deal_structure}
                          </span>
                        </span>
                      )}
                      {deal.industry_sector && (
                        <span className="flex items-center gap-1.5">
                          <span className="text-slate-600">Sector:</span>
                          <span className="text-slate-300">{deal.industry_sector}</span>
                        </span>
                      )}
                      {deal.deal_value_range && (
                        <span className="flex items-center gap-1.5">
                          <span className="text-slate-600">Value:</span>
                          <span className="text-slate-300">{deal.deal_value_range}</span>
                        </span>
                      )}
                      {deal.cross_border && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 text-[10px] font-semibold">
                          Cross-Border
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Bottom bar */}
                  <div className="px-6 py-3 bg-[#0D1117] border-t border-[#1E293B] rounded-b-xl flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      443 checklist items · 12 workstreams · 7 risk categories
                    </span>
                    <span className="text-[11px] text-amber-400/70 font-medium group-hover:text-amber-400 transition-colors">
                      Open Dashboard →
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Setup Instructions */}
          {!dbConnected && (
            <div className="mt-10 card p-6">
              <h3 className="text-sm font-semibold text-white mb-3">Quick Setup</h3>
              <div className="space-y-2 text-xs text-slate-400 font-mono">
                <p><span className="text-slate-600">1.</span> <span className="text-emerald-400">cp</span> .env.example .env</p>
                <p><span className="text-slate-600">2.</span> Add your Neon DATABASE_URL to .env</p>
                <p><span className="text-slate-600">3.</span> <span className="text-emerald-400">npm run</span> db:migrate</p>
                <p><span className="text-slate-600">4.</span> <span className="text-emerald-400">npm run</span> db:seed</p>
                <p><span className="text-slate-600">5.</span> <span className="text-emerald-400">npm run</span> dev</p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1E293B] px-8 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between text-[11px] text-slate-600">
          <span>M&A Integration Engine · Pre-Demo v0.1</span>
          <span>Finance & Accounting · 443 Items · 12 Workstreams</span>
        </div>
      </footer>
    </div>
  );
}
