"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { KPICard, ProgressBar, SeverityBadge, StatusBadge, PhaseBadge, DashboardSkeleton } from "@/components/ui";
import { DEAL_STRUCTURE_LABELS, PHASE_LABELS, WORKSTREAM_SHORT } from "@/lib/types";

// ============================================================
// DEMO FALLBACK DATA (used when DB isn't connected)
// ============================================================
const DEMO = {
  deal: {
    name: "Meridian Acquisition",
    code_name: "Project Meridian",
    stage: "stage_3_execute_track",
    deal_structure: "merger_reverse_triangular",
    integration_model: "fully_integrated",
    target_close_date: "2026-04-15",
    cross_border: true,
    cross_border_jurisdictions: ["US", "EU", "UK"],
    tsa_required: "yes",
    industry_sector: "Technology",
    deal_value_range: "$1B–$5B",
    target_legal_entities: "12",
    target_gaap_framework: "IFRS",
    buyer_ma_maturity: "Serial acquirer (5+ deals)",
  },
  stats: { total: 131, complete: 34, in_progress: 38, blocked: 7, not_started: 52 },
  progress: [
    { workstream: "Consolidation & Reporting", total_items: 21, complete: 8, in_progress: 7, blocked: 1, not_started: 5, completion_pct: 38.1 },
    { workstream: "Cybersecurity & Data Privacy", total_items: 10, complete: 4, in_progress: 3, blocked: 1, not_started: 2, completion_pct: 40.0 },
    { workstream: "ESG & Sustainability", total_items: 5, complete: 0, in_progress: 1, blocked: 0, not_started: 4, completion_pct: 0.0 },
    { workstream: "FP&A & Baselining", total_items: 7, complete: 2, in_progress: 2, blocked: 0, not_started: 3, completion_pct: 28.6 },
    { workstream: "Facilities & Real Estate", total_items: 4, complete: 1, in_progress: 1, blocked: 0, not_started: 2, completion_pct: 25.0 },
    { workstream: "Income Tax & Compliance", total_items: 15, complete: 5, in_progress: 4, blocked: 1, not_started: 5, completion_pct: 33.3 },
    { workstream: "Integration Budget & PMO", total_items: 9, complete: 4, in_progress: 3, blocked: 0, not_started: 2, completion_pct: 44.4 },
    { workstream: "Internal Controls & SOX", total_items: 10, complete: 3, in_progress: 3, blocked: 0, not_started: 4, completion_pct: 30.0 },
    { workstream: "Operational Accounting", total_items: 22, complete: 6, in_progress: 7, blocked: 2, not_started: 7, completion_pct: 27.3 },
    { workstream: "TSA Assessment & Exit", total_items: 26, complete: 3, in_progress: 8, blocked: 2, not_started: 13, completion_pct: 11.5 },
    { workstream: "Treasury & Banking", total_items: 10, complete: 4, in_progress: 3, blocked: 0, not_started: 3, completion_pct: 40.0 },
  ],
  risks: [
    { id: "r1", category: "Regulatory Delay", severity: "critical", description: "CFIUS filing pending — 3 jurisdictions require review. Target close April 15.", related_workstream: "Income Tax & Compliance", mitigation_status: "in_progress" },
    { id: "r2", category: "Day 1 Readiness Failure", severity: "high", description: "28 days to close. 15 of 50 Day 1 critical items still Not Started.", related_workstream: "Integration Budget & PMO", mitigation_status: "in_progress" },
    { id: "r3", category: "TSA Dependency", severity: "high", description: "IT Infrastructure TSA >12 months. No standalone assessment for 4 of 6 services.", related_workstream: "TSA Assessment & Exit", mitigation_status: "open" },
    { id: "r4", category: "Data Privacy Breach", severity: "high", description: "EU personal data processing — GDPR DPIA not initiated. AI systems in scope.", related_workstream: "Cybersecurity & Data Privacy", mitigation_status: "open" },
    { id: "r5", category: "Financial Reporting Gap", severity: "high", description: "IFRS target, US GAAP acquirer. 12 entities, separate ledgers.", related_workstream: "Consolidation & Reporting", mitigation_status: "in_progress" },
    { id: "r6", category: "Tax Structure Leakage", severity: "medium", description: "2 jurisdictions ETR <15%. Pillar Two analysis not started.", related_workstream: "Income Tax & Compliance", mitigation_status: "open" },
  ],
  milestones: [
    { phase: "pre_close", label: "Pre-Close Preparation", target_date: "2026-04-01", status: "active" },
    { phase: "day_1", label: "Day 1 / Close", target_date: "2026-04-15", status: "upcoming" },
    { phase: "day_30", label: "Day 30 Checkpoint", target_date: "2026-05-15", status: "upcoming" },
    { phase: "day_60", label: "Day 60 Review", target_date: "2026-06-14", status: "upcoming" },
    { phase: "day_90", label: "Day 90 SteerCo", target_date: "2026-07-14", status: "upcoming" },
    { phase: "year_1", label: "Year 1 Close-Out", target_date: "2027-04-15", status: "upcoming" },
  ],
};

export default function DashboardPage() {
  const params = useParams();
  const dealId = params.dealId as string;
  const [data, setData] = useState<any>(DEMO);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (dealId === "demo") {
      setLoading(false);
      return;
    }
    fetch(`/api/deals/${dealId}`)
      .then((r) => r.json())
      .then((d) => { if (d.deal) setData(d); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [dealId]);

  if (loading) return <DashboardSkeleton />;

  const { deal, stats, progress, risks, milestones } = data;
  const totalPct = stats.total > 0 ? Math.round((stats.complete / stats.total) * 100) : 0;
  const daysToClose = deal.target_close_date
    ? Math.ceil((new Date(deal.target_close_date).getTime() - Date.now()) / 86400000)
    : null;

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      {/* Page Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
            PMO Dashboard
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            {deal.code_name || deal.name} · {deal.industry_sector}
            {deal.cross_border ? " · Cross-Border" : ""}
          </p>
        </div>
        {daysToClose !== null && (
          <div className="text-right">
            <div className={`text-3xl font-bold tabular-nums ${daysToClose <= 14 ? "text-red-400" : daysToClose <= 30 ? "text-amber-400" : "text-white"}`}>
              {daysToClose}
            </div>
            <div className="text-[10px] text-slate-500 uppercase tracking-widest">Days to Close</div>
          </div>
        )}
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <KPICard label="Overall Progress" value={`${totalPct}%`} subtitle={`${stats.complete} of ${stats.total} items`} color="#059669" />
        <KPICard label="In Progress" value={stats.in_progress} subtitle="Active items" color="#2563EB" />
        <KPICard label="Blocked" value={stats.blocked} subtitle="Require attention" color="#9333EA" />
        <KPICard label="Active Risks" value={risks.length} subtitle={`${risks.filter((r: any) => r.severity === "critical").length} critical`} color="#DC2626" />
        <KPICard label="Workstreams" value={progress.length} subtitle={`${progress.filter((p: any) => p.completion_pct > 0).length} active`} color="#D97706" />
      </div>

      {/* Deal Profile Banner */}
      <div className="card">
        <div className="px-5 py-3 border-b border-[#1E293B] flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Deal Profile</span>
          <span className="text-[10px] text-slate-600">
            Close: {deal.target_close_date ? new Date(deal.target_close_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "TBD"}
          </span>
        </div>
        <div className="px-5 py-3 flex flex-wrap gap-x-8 gap-y-2 text-xs">
          <div><span className="text-slate-500">Structure:</span>{" "}<span className="text-slate-200">{DEAL_STRUCTURE_LABELS[deal.deal_structure as keyof typeof DEAL_STRUCTURE_LABELS] || deal.deal_structure}</span></div>
          <div><span className="text-slate-500">Model:</span>{" "}<span className="text-slate-200 capitalize">{deal.integration_model?.replace(/_/g, " ")}</span></div>
          <div><span className="text-slate-500">Value:</span>{" "}<span className="text-slate-200">{deal.deal_value_range}</span></div>
          <div><span className="text-slate-500">Entities:</span>{" "}<span className="text-slate-200">{deal.target_legal_entities}</span></div>
          <div><span className="text-slate-500">GAAP:</span>{" "}<span className="text-slate-200">{deal.target_gaap_framework}</span></div>
          {deal.cross_border && (
            <div><span className="text-slate-500">Jurisdictions:</span>{" "}<span className="text-blue-400">{(deal.cross_border_jurisdictions || []).join(", ")}</span></div>
          )}
          <div><span className="text-slate-500">TSA:</span>{" "}<span className="text-slate-200 capitalize">{deal.tsa_required}</span></div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Workstream Progress (2 cols) */}
        <div className="xl:col-span-2 card">
          <div className="card-header flex items-center justify-between">
            <span className="text-sm font-semibold text-white">Workstream Progress</span>
            <Link href={`/deal/${dealId}/checklist`} className="text-[11px] text-amber-400/70 hover:text-amber-400 transition-colors">
              View Checklist →
            </Link>
          </div>
          <div className="p-4">
            <div className="space-y-1">
              {/* Header */}
              <div className="grid grid-cols-[200px_1fr_50px_50px_50px_50px_50px] gap-2 px-3 py-2 text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                <div>Workstream</div>
                <div>Progress</div>
                <div className="text-center">Done</div>
                <div className="text-center">Active</div>
                <div className="text-center">Block</div>
                <div className="text-center">Queue</div>
                <div className="text-right">%</div>
              </div>
              {progress.map((ws: any, i: number) => {
                const pct = Number(ws.completion_pct) || 0;
                return (
                  <Link
                    key={ws.workstream}
                    href={`/deal/${dealId}/checklist?workstream=${encodeURIComponent(ws.workstream)}`}
                    className="grid grid-cols-[200px_1fr_50px_50px_50px_50px_50px] gap-2 px-3 py-2.5 rounded-lg hover:bg-white/[0.03] transition-colors items-center"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-[10px] font-bold text-amber-400/60 w-7">{WORKSTREAM_SHORT[ws.workstream]}</span>
                      <span className="text-xs text-slate-300 truncate">{ws.workstream}</span>
                    </div>
                    <ProgressBar value={Number(ws.complete)} max={Number(ws.total_items)} size="sm" />
                    <div className="text-center text-xs text-emerald-400 font-semibold tabular-nums">{ws.complete}</div>
                    <div className="text-center text-xs text-blue-400 font-semibold tabular-nums">{ws.in_progress}</div>
                    <div className="text-center text-xs font-semibold tabular-nums" style={{ color: Number(ws.blocked) > 0 ? "#A855F7" : "#334155" }}>{ws.blocked}</div>
                    <div className="text-center text-xs text-slate-500 tabular-nums">{ws.not_started}</div>
                    <div className="text-right text-xs font-semibold tabular-nums" style={{ color: pct >= 50 ? "#059669" : pct > 0 ? "#D97706" : "#475569" }}>
                      {pct}%
                    </div>
                  </Link>
                );
              })}
            </div>
            {/* Summary row */}
            <div className="grid grid-cols-[200px_1fr_50px_50px_50px_50px_50px] gap-2 px-3 py-3 mt-2 border-t border-[#1E293B] text-xs font-semibold">
              <div className="text-slate-300">Total</div>
              <ProgressBar value={stats.complete} max={stats.total} size="md" showLabel={false} />
              <div className="text-center text-emerald-400 tabular-nums">{stats.complete}</div>
              <div className="text-center text-blue-400 tabular-nums">{stats.in_progress}</div>
              <div className="text-center text-purple-400 tabular-nums">{stats.blocked}</div>
              <div className="text-center text-slate-500 tabular-nums">{stats.not_started}</div>
              <div className="text-right text-white tabular-nums">{totalPct}%</div>
            </div>
          </div>
        </div>

        {/* Risk Alerts (1 col) */}
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <span className="text-sm font-semibold text-white">Risk Alerts</span>
            <Link href={`/deal/${dealId}/risks`} className="text-[11px] text-amber-400/70 hover:text-amber-400 transition-colors">
              Full Register →
            </Link>
          </div>
          <div className="p-3 space-y-2 max-h-[480px] overflow-y-auto">
            {risks.map((risk: any) => (
              <div key={risk.id} className="px-3 py-3 rounded-lg bg-[#0D1117] border border-[#1E293B] hover:border-[#2D3B4E] transition-colors">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-xs font-semibold text-white">{risk.category}</span>
                  <SeverityBadge severity={risk.severity} />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed mb-2">{risk.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-600">{risk.related_workstream}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 capitalize">
                    {risk.mitigation_status?.replace(/_/g, " ")}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Milestone Timeline */}
      <div className="card">
        <div className="card-header">
          <span className="text-sm font-semibold text-white">Integration Timeline</span>
        </div>
        <div className="p-5">
          <div className="relative">
            {/* Line */}
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-[#1E293B]" />
            {/* Milestones */}
            <div className="relative flex justify-between">
              {milestones.map((ms: any, i: number) => {
                const isActive = ms.status === "active";
                const isPast = ms.status === "complete";
                const date = new Date(ms.target_date);
                return (
                  <div key={ms.phase} className="flex flex-col items-center text-center" style={{ minWidth: 80 }}>
                    <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-[10px] font-bold z-10 ${
                      isActive ? "bg-amber-500 border-amber-400 text-white" :
                      isPast ? "bg-emerald-600 border-emerald-500 text-white" :
                      "bg-[#111827] border-[#334155] text-slate-500"
                    }`}>
                      {isPast ? "✓" : PHASE_LABELS[ms.phase as keyof typeof PHASE_LABELS]?.replace(/Day /, "D").replace("Pre-Close", "Pre") || ""}
                    </div>
                    <div className={`text-[11px] font-semibold mt-2 ${isActive ? "text-amber-400" : "text-slate-400"}`}>
                      {ms.label}
                    </div>
                    <div className="text-[10px] text-slate-600 mt-0.5">
                      {date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
