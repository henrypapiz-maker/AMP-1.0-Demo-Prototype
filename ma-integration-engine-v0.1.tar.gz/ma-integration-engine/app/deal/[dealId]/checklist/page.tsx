"use client";

import { useState, useEffect, useMemo } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import { StatusBadge, PriorityBadge, PhaseBadge, ProgressBar, Skeleton } from "@/components/ui";
import { ALL_WORKSTREAMS, WORKSTREAM_SHORT, STATUS_LABELS, PHASE_LABELS } from "@/lib/types";
import type { ChecklistStatus, MilestonePhase, PriorityLevel } from "@/lib/types";

// Demo checklist items
const DEMO_ITEMS = generateDemoItems();

function generateDemoItems() {
  const items: any[] = [];
  const workstreams = [
    { ws: "TSA Assessment & Exit", sections: ["Service Inventory & Categorization", "SLA Definition & Pricing", "Exit Planning", "TSA Governance"] },
    { ws: "Consolidation & Reporting", sections: ["Chart of Accounts Mapping", "Close Process Design", "Financial Reporting", "GAAP Alignment"] },
    { ws: "Operational Accounting", sections: ["Accounts Payable", "Accounts Receivable", "Payroll", "Fixed Assets", "General Ledger"] },
    { ws: "Internal Controls & SOX", sections: ["Control Environment Assessment", "SOX Integration"] },
    { ws: "Income Tax & Compliance", sections: ["Tax Structure & Entity", "Transfer Pricing", "International Tax", "Regulatory Filings"] },
    { ws: "Treasury & Banking", sections: ["Bank Account Management", "Cash Management", "Debt & Credit Facilities"] },
    { ws: "FP&A & Baselining", sections: ["Baseline Financial Model", "Synergy Tracking"] },
    { ws: "Cybersecurity & Data Privacy", sections: ["Security Assessment", "Data Privacy Compliance"] },
    { ws: "ESG & Sustainability", sections: ["ESG Assessment"] },
    { ws: "Integration Budget & PMO", sections: ["Program Setup", "Budget Tracking"] },
    { ws: "Facilities & Real Estate", sections: ["Lease & Property Review"] },
  ];

  const descriptions: Record<string, string[]> = {
    "Service Inventory & Categorization": ["Identify all shared services currently provided by seller", "Categorize TSA services by function", "Document current service delivery model", "Assess service criticality and business impact"],
    "SLA Definition & Pricing": ["Define service level metrics for each TSA service", "Establish baseline performance measurements", "Develop TSA pricing model"],
    "Exit Planning": ["Develop TSA exit timeline for each service", "Identify buyer standalone capability requirements", "Assess build vs buy vs outsource options"],
    "TSA Governance": ["Establish TSA governance committee structure", "Define TSA performance reporting requirements"],
    "Chart of Accounts Mapping": ["Obtain target's complete chart of accounts", "Map target COA to acquirer COA", "Identify COA gaps requiring new accounts"],
    "Close Process Design": ["Document target's current month-end close calendar", "Design integrated close calendar for Day 1", "Create purchase accounting journal entry templates"],
    "Financial Reporting": ["Assess statutory reporting requirements by jurisdiction", "Define consolidated management reporting package"],
    "GAAP Alignment": ["Identify accounting policy differences", "Quantify impact of policy alignment changes", "Assess revenue recognition alignment (ASC 606)"],
    "Accounts Payable": ["Map target AP process end-to-end", "Identify critical vendor relationships for Day 1", "Establish AP cutoff procedures"],
    "Accounts Receivable": ["Map target AR process and collections workflow", "Establish customer notification for banking changes"],
    "Payroll": ["Map target payroll process, pay cycles, systems", "Ensure Day 1 payroll continuity plan", "Establish payroll tax withholding for new entity"],
    "Fixed Assets": ["Obtain target's fixed asset register", "Assess PPA impact on fixed assets"],
    "General Ledger": ["Establish Day 1 opening balance sheet", "Design journal entry approval workflow"],
    "Control Environment Assessment": ["Assess target's internal control framework", "Identify SOX-relevant processes", "Map controls to COSO framework"],
    "SOX Integration": ["Define SOX compliance timeline", "Establish interim controls for Day 1"],
    "Tax Structure & Entity": ["Analyze tax implications of deal structure", "Assess 338(h)(10) election economics"],
    "Transfer Pricing": ["Review target's transfer pricing documentation", "Assess arm's-length compliance"],
    "International Tax": ["Assess Pillar Two top-up tax exposure", "Review GILTI/FDII implications"],
    "Regulatory Filings": ["Identify HSR Act filing requirements", "Assess CFIUS filing requirements", "Map regulatory filing deadlines"],
    "Bank Account Management": ["Inventory all target bank accounts", "Establish Day 1 cash management plan", "Execute bank signatory changes"],
    "Cash Management": ["Assess target's cash pooling arrangements", "Design integrated cash forecasting"],
    "Debt & Credit Facilities": ["Review existing debt covenants and change-of-control", "Assess acquisition financing compliance"],
    "Baseline Financial Model": ["Build standalone financial model", "Establish normalized EBITDA baseline"],
    "Synergy Tracking": ["Define synergy categories", "Establish synergy tracking methodology"],
    "Security Assessment": ["Conduct cybersecurity risk assessment", "Inventory IT systems and data repos", "Assess identity and access management"],
    "Data Privacy Compliance": ["Conduct GDPR DPIA", "Review cross-border data transfer mechanisms"],
    "ESG Assessment": ["Assess target's ESG maturity", "Evaluate EU CSRD reporting obligations", "Review environmental compliance"],
    "Program Setup": ["Establish IMO structure and governance", "Define integration budget by workstream", "Create RACI matrix"],
    "Budget Tracking": ["Establish budget tracking and variance reporting", "Define cost category taxonomy"],
    "Lease & Property Review": ["Inventory all target leases and owned properties", "Review change-of-control provisions in leases"],
  };

  let counter = 1;
  const statuses: ChecklistStatus[] = ["not_started", "in_progress", "complete", "blocked", "not_applicable"];
  const phases: MilestonePhase[] = ["pre_close", "day_1", "day_30", "day_60", "day_90"];
  const priorities: PriorityLevel[] = ["critical", "high", "medium", "low"];
  const owners = ["Sarah Chen", "James Miller", "Priya Patel", null];

  for (const { ws, sections } of workstreams) {
    for (const sec of sections) {
      const descs = descriptions[sec] || [`Complete ${sec} activities`];
      for (const desc of descs) {
        const phase = phases[Math.floor(Math.random() * 3)]; // bias toward early phases
        const status = phase === "pre_close" ? (Math.random() < 0.6 ? "complete" : "in_progress") :
                       phase === "day_1" ? statuses[Math.floor(Math.random() * 4)] :
                       Math.random() < 0.7 ? "not_started" : "in_progress";
        items.push({
          id: `item-${counter}`,
          source_item_id: `FRC-${String(counter).padStart(4, "0")}`,
          workstream: ws,
          section: sec,
          description: desc,
          status,
          phase,
          priority: priorities[Math.floor(Math.random() * 3)],
          milestone_date: "2026-04-15",
          owner_name: status !== "not_started" ? owners[Math.floor(Math.random() * 3)] : null,
          is_active: true,
          blocked_reason: status === "blocked" ? "Pending external input" : null,
        });
        counter++;
      }
    }
  }
  return items;
}

export default function ChecklistPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const dealId = params.dealId as string;

  const [items, setItems] = useState<any[]>(DEMO_ITEMS);
  const [loading, setLoading] = useState(true);
  const [filterWorkstream, setFilterWorkstream] = useState(searchParams.get("workstream") || "");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterPhase, setFilterPhase] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [groupBy, setGroupBy] = useState<"workstream" | "phase" | "status">("workstream");

  useEffect(() => {
    if (dealId === "demo") { setLoading(false); return; }
    const qs = new URLSearchParams();
    if (filterWorkstream) qs.set("workstream", filterWorkstream);
    if (filterStatus) qs.set("status", filterStatus);
    if (filterPhase) qs.set("phase", filterPhase);
    if (searchQuery) qs.set("q", searchQuery);

    fetch(`/api/deals/${dealId}/checklist?${qs}`)
      .then((r) => r.json())
      .then((d) => { if (d.items) setItems(d.items); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [dealId, filterWorkstream, filterStatus, filterPhase, searchQuery]);

  // Client-side filtering for demo mode
  const filtered = useMemo(() => {
    let f = items;
    if (filterWorkstream) f = f.filter((i) => i.workstream === filterWorkstream);
    if (filterStatus) f = f.filter((i) => i.status === filterStatus);
    if (filterPhase) f = f.filter((i) => i.phase === filterPhase);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      f = f.filter((i) => i.description.toLowerCase().includes(q) || i.section.toLowerCase().includes(q));
    }
    return f;
  }, [items, filterWorkstream, filterStatus, filterPhase, searchQuery]);

  // Group items
  const grouped = useMemo(() => {
    const groups: Record<string, any[]> = {};
    for (const item of filtered) {
      const key = item[groupBy] || "Other";
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    }
    return groups;
  }, [filtered, groupBy]);

  // Stats
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { not_started: 0, in_progress: 0, complete: 0, blocked: 0, not_applicable: 0 };
    for (const item of filtered) counts[item.status] = (counts[item.status] || 0) + 1;
    return counts;
  }, [filtered]);

  const handleStatusChange = async (itemId: string, newStatus: ChecklistStatus) => {
    // Optimistic update
    setItems((prev) => prev.map((i) => i.id === itemId ? { ...i, status: newStatus } : i));
    if (dealId !== "demo") {
      await fetch(`/api/deals/${dealId}/checklist`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemId, status: newStatus }),
      });
    }
  };

  return (
    <div className="p-6 space-y-5 max-w-[1400px]">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
            Integration Checklist
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            {filtered.length} items{filterWorkstream ? ` in ${filterWorkstream}` : ""} · 443 total in master taxonomy
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" />{statusCounts.complete} Done</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" />{statusCounts.in_progress} Active</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-purple-500" />{statusCounts.blocked} Blocked</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-500" />{statusCounts.not_started} Queue</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-3 flex flex-wrap items-center gap-3">
        {/* Search */}
        <input
          type="text"
          placeholder="Search items..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50 w-64"
        />
        {/* Workstream filter */}
        <select
          value={filterWorkstream}
          onChange={(e) => setFilterWorkstream(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-slate-300 focus:outline-none focus:border-amber-500/50"
        >
          <option value="">All Workstreams</option>
          {ALL_WORKSTREAMS.map((ws) => (
            <option key={ws} value={ws}>{ws}</option>
          ))}
        </select>
        {/* Status filter */}
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-slate-300 focus:outline-none"
        >
          <option value="">All Statuses</option>
          {Object.entries(STATUS_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </select>
        {/* Phase filter */}
        <select
          value={filterPhase}
          onChange={(e) => setFilterPhase(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-slate-300 focus:outline-none"
        >
          <option value="">All Phases</option>
          {Object.entries(PHASE_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </select>
        {/* Group toggle */}
        <div className="ml-auto flex items-center gap-1 bg-[#0D1117] rounded-lg border border-[#1E293B] p-0.5">
          {(["workstream", "phase", "status"] as const).map((g) => (
            <button
              key={g}
              onClick={() => setGroupBy(g)}
              className={`px-3 py-1.5 text-[11px] rounded-md font-medium transition-colors ${groupBy === g ? "bg-white/10 text-white" : "text-slate-500 hover:text-slate-300"}`}
            >
              {g === "workstream" ? "Workstream" : g === "phase" ? "Phase" : "Status"}
            </button>
          ))}
        </div>
      </div>

      {/* Grouped Items */}
      <div className="space-y-4">
        {Object.entries(grouped).map(([group, groupItems]) => {
          const complete = groupItems.filter((i: any) => i.status === "complete").length;
          const total = groupItems.length;

          return (
            <div key={group} className="card">
              <div className="card-header flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {groupBy === "workstream" && (
                    <span className="text-[10px] font-bold text-amber-400/60 bg-amber-500/5 px-2 py-0.5 rounded">
                      {WORKSTREAM_SHORT[group] || "—"}
                    </span>
                  )}
                  <span className="text-sm font-semibold text-white">
                    {groupBy === "phase" ? PHASE_LABELS[group as MilestonePhase] || group :
                     groupBy === "status" ? STATUS_LABELS[group as ChecklistStatus] || group :
                     group}
                  </span>
                  <span className="text-[11px] text-slate-500">{total} items</span>
                </div>
                <div className="flex items-center gap-3 w-48">
                  <ProgressBar value={complete} max={total} size="sm" showLabel />
                </div>
              </div>
              <div className="divide-y divide-[#1E293B]/50">
                {groupItems.map((item: any) => (
                  <div key={item.id}>
                    <div
                      className="px-5 py-3 flex items-center gap-4 hover:bg-white/[0.02] transition-colors cursor-pointer"
                      onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                    >
                      {/* Status dot / clickable */}
                      <div className="flex-shrink-0">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const next: Record<string, ChecklistStatus> = {
                              not_started: "in_progress",
                              in_progress: "complete",
                              complete: "not_started",
                              blocked: "in_progress",
                            };
                            handleStatusChange(item.id, next[item.status] || "not_started");
                          }}
                          className="w-5 h-5 rounded border-2 flex items-center justify-center transition-all hover:scale-110"
                          style={{
                            borderColor: item.status === "complete" ? "#059669" : item.status === "in_progress" ? "#2563EB" : item.status === "blocked" ? "#9333EA" : "#475569",
                            background: item.status === "complete" ? "#059669" : "transparent",
                          }}
                          title="Click to cycle status"
                        >
                          {item.status === "complete" && <span className="text-white text-[10px]">✓</span>}
                          {item.status === "in_progress" && <span className="w-2 h-2 rounded-full bg-blue-500" />}
                          {item.status === "blocked" && <span className="text-purple-400 text-[10px]">!</span>}
                        </button>
                      </div>
                      {/* Item ID */}
                      <span className="text-[10px] font-mono text-slate-600 w-16 flex-shrink-0">{item.source_item_id}</span>
                      {/* Description */}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${item.status === "complete" ? "text-slate-500 line-through" : "text-slate-200"}`}>
                          {item.description}
                        </p>
                        <p className="text-[10px] text-slate-600 mt-0.5">{item.section}</p>
                      </div>
                      {/* Metadata */}
                      <PhaseBadge phase={item.phase} />
                      <PriorityBadge priority={item.priority} />
                      <div className="w-24 text-right">
                        {item.owner_name ? (
                          <span className="text-[11px] text-slate-400">{item.owner_name}</span>
                        ) : (
                          <span className="text-[11px] text-slate-600 italic">Unassigned</span>
                        )}
                      </div>
                      <span className="text-slate-600 text-xs">{expandedItem === item.id ? "▾" : "▸"}</span>
                    </div>
                    {/* Expanded Detail */}
                    {expandedItem === item.id && (
                      <div className="px-5 py-4 bg-[#0A0F1A] border-t border-[#1E293B]/50 animate-fade-in">
                        <div className="grid grid-cols-3 gap-6 text-xs">
                          <div>
                            <div className="text-slate-500 mb-1 uppercase tracking-wider text-[10px]">Status</div>
                            <StatusBadge status={item.status} />
                            {item.blocked_reason && (
                              <p className="text-[11px] text-purple-300 mt-1">Reason: {item.blocked_reason}</p>
                            )}
                          </div>
                          <div>
                            <div className="text-slate-500 mb-1 uppercase tracking-wider text-[10px]">Milestone Date</div>
                            <span className="text-slate-300">{item.milestone_date ? new Date(item.milestone_date).toLocaleDateString() : "—"}</span>
                          </div>
                          <div>
                            <div className="text-slate-500 mb-1 uppercase tracking-wider text-[10px]">Dependencies</div>
                            <span className="text-slate-400">—</span>
                          </div>
                        </div>
                        {/* Status change buttons */}
                        <div className="mt-4 flex items-center gap-2">
                          <span className="text-[10px] text-slate-500 uppercase tracking-wider mr-2">Set Status:</span>
                          {(["not_started", "in_progress", "blocked", "complete"] as const).map((s) => (
                            <button
                              key={s}
                              onClick={() => handleStatusChange(item.id, s)}
                              className={`px-2.5 py-1 rounded text-[10px] font-semibold uppercase tracking-wider transition-colors ${
                                item.status === s
                                  ? "bg-white/10 text-white"
                                  : "bg-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5"
                              }`}
                            >
                              {STATUS_LABELS[s]}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
