"use client";

import { AppShell } from "@/components/AppShell";
import { useParams } from "next/navigation";

export default function DealLayout({ children }: { children: React.ReactNode }) {
  const params = useParams();
  const dealId = params.dealId as string;

  return (
    <AppShell dealId={dealId} dealName="Project Meridian">
      {children}
    </AppShell>
  );
}
