"use client";

import { useState, useEffect, useMemo } from "react";
import { useParams } from "next/navigation";
import { SeverityBadge, ProgressBar } from "@/components/ui";
import { WORKSTREAM_SHORT } from "@/lib/types";
import type { RiskSeverity } from "@/lib/types";

const DEMO_RISKS = [
  {
    id: "r1", category: "Regulatory Delay", severity: "critical" as RiskSeverity,
    description: "CFIUS filing pending — 3 jurisdictions (US, EU, UK) require regulatory approval. Target close date April 15 is less than 30 days out. EUMR filing threshold exceeded based on combined revenue. HSR waiting period not yet expired.",
    indicators: ["Multiple jurisdictions requiring approval", "Deal value exceeds HSR threshold", "Sensitive sector (technology)", "CFIUS filing required"],
    mitigations: ["Pre-file regulatory submissions — COMPLETE", "Engage regulatory counsel — IN PROGRESS", "Prepare CFIUS voluntary filing — IN PROGRESS", "Monitor regulatory calendar weekly"],
    related_workstream: "Income Tax & Compliance", mitigation_status: "in_progress", owner_name: "James Miller",
    detected_at: "2026-02-01", related_checklist_items: ["FRC-0078", "FRC-0079", "FRC-0081"]
  },
  {
    id: "r2", category: "Day 1 Readiness Failure", severity: "high" as RiskSeverity,
    description: "28 days to close. 15 of 50 Day 1 critical items remain Not Started. Payroll continuity confirmation pending from target HR. Bank signatory changes not initiated for 3 of 8 accounts.",
    indicators: ["Day 1 critical items incomplete", "Payroll continuity unconfirmed", "Bank accounts not transitioned"],
    mitigations: ["Daily standup on Day 1 items", "Escalate blockers to SteerCo", "Identify minimum viable Day 1 scope", "Prepare contingency plans for delayed items"],
    related_workstream: "Integration Budget & PMO", mitigation_status: "in_progress", owner_name: "Sarah Chen",
    detected_at: "2026-03-01", related_checklist_items: ["FRC-0115", "FRC-0116", "FRC-0062"]
  },
  {
    id: "r3", category: "TSA Dependency", severity: "high" as RiskSeverity,
    description: "IT Infrastructure TSA projected to exceed 12 months. No standalone capability assessment has been initiated for 4 of 6 TSA service categories. Exit criteria undefined for Finance shared services. Estimated TSA cost $2.4M/year if extended.",
    indicators: ["TSA duration >12 months", "No standalone capability plan", "IT infrastructure dependency", "Critical finance services on TSA"],
    mitigations: ["Accelerate standalone capability build", "Define TSA exit criteria per service", "Establish TSA governance committee", "Budget for TSA extensions"],
    related_workstream: "TSA Assessment & Exit", mitigation_status: "open", owner_name: "James Miller",
    detected_at: "2026-02-15", related_checklist_items: ["FRC-0001", "FRC-0015", "FRC-0020"]
  },
  {
    id: "r4", category: "Data Privacy Breach", severity: "high" as RiskSeverity,
    description: "Target processes EU personal data across 3 jurisdictions (DE, NL, UK). GDPR Data Protection Impact Assessment not yet initiated. Target operates AI-powered systems that may fall within EU AI Act scope. No assessment of Standard Contractual Clauses for cross-border data transfers.",
    indicators: ["EU personal data processing", "No DPIA initiated", "Cross-border data transfers", "AI systems processing personal data"],
    mitigations: ["Initiate GDPR DPIA immediately", "Review Standard Contractual Clauses", "Assess AI Act compliance requirements", "Appoint Data Protection Officer for new entity"],
    related_workstream: "Cybersecurity & Data Privacy", mitigation_status: "open", owner_name: "James Miller",
    detected_at: "2026-02-20", related_checklist_items: ["FRC-0098", "FRC-0099"]
  },
  {
    id: "r5", category: "Financial Reporting Gap", severity: "high" as RiskSeverity,
    description: "Target uses IFRS; acquirer uses US GAAP. 12 legal entities with separate ledgers across 3 jurisdictions. No consolidated reporting capability exists today. COA mapping exercise not started. First combined close target is Day 30.",
    indicators: ["Different GAAP frameworks (IFRS vs US GAAP)", ">5 legal entities", "No consolidated reporting capability"],
    mitigations: ["Early COA mapping initiative — IN PROGRESS", "Establish interim reporting bridge", "Hire experienced consolidation resources", "Deploy close calendar Day 1"],
    related_workstream: "Consolidation & Reporting", mitigation_status: "in_progress", owner_name: "Priya Patel",
    detected_at: "2026-02-10", related_checklist_items: ["FRC-0027", "FRC-0028", "FRC-0032"]
  },
  {
    id: "r6", category: "Tax Structure Leakage", severity: "medium" as RiskSeverity,
    description: "2 jurisdictions show effective tax rate below 15%. Pillar Two Global Minimum Tax top-up analysis not initiated. Transfer pricing documentation has gaps for intercompany service charges. Withholding tax structure for dividend repatriation not optimized.",
    indicators: ["Jurisdictions with ETR <15%", "Pillar Two exposure", "Transfer pricing gaps", "Missing WHT optimization"],
    mitigations: ["Complete Pillar Two ETR analysis", "Update transfer pricing documentation", "Optimize withholding tax structure", "Model post-close consolidated ETR"],
    related_workstream: "Income Tax & Compliance", mitigation_status: "open", owner_name: null,
    detected_at: "2026-03-05", related_checklist_items: ["FRC-0070", "FRC-0072"]
  },
  {
    id: "r7", category: "Control Environment Gap", severity: "medium" as RiskSeverity,
    description: "Target has no formal SOX program. Interim control framework needed for Day 1 through system integration. Segregation of duties analysis not performed for target's finance team. IT general control assessment shows material gaps in access management.",
    indicators: ["No interim control framework", "Segregation of duties gaps", "IT general control weaknesses"],
    mitigations: ["Establish interim control framework Day 1", "Map target controls to buyer framework", "Engage internal audit early", "Design compensating controls"],
    related_workstream: "Internal Controls & SOX", mitigation_status: "open", owner_name: null,
    detected_at: "2026-03-10", related_checklist_items: ["FRC-0049", "FRC-0054"]
  },
];

const SEVERITY_ORDER: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3, resolved: 4 };

export default function RisksPage() {
  const params = useParams();
  const dealId = params.dealId as string;
  const [risks, setRisks] = useState(DEMO_RISKS);
  const [loading, setLoading] = useState(true);
  const [expandedRisk, setExpandedRisk] = useState<string | null>(null);
  const [filterSeverity, setFilterSeverity] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  useEffect(() => {
    if (dealId === "demo") { setLoading(false); return; }
    fetch(`/api/deals/${dealId}/risks`)
      .then((r) => r.json())
      .then((d) => { if (d.risks?.length) setRisks(d.risks); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [dealId]);

  const filtered = useMemo(() => {
    let f = risks;
    if (filterSeverity) f = f.filter((r) => r.severity === filterSeverity);
    if (filterStatus) f = f.filter((r) => r.mitigation_status === filterStatus);
    return f.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);
  }, [risks, filterSeverity, filterStatus]);

  // Summary counts
  const counts = useMemo(() => {
    const c: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    risks.forEach((r) => { c[r.severity] = (c[r.severity] || 0) + 1; });
    return c;
  }, [risks]);

  return (
    <div className="p-6 space-y-6 max-w-[1400px]">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Risk Register
        </h1>
        <p className="text-sm text-slate-400 mt-0.5">
          {risks.length} active risks across 7 categories · Project Meridian
        </p>
      </div>

      {/* Severity Summary Cards */}
      <div className="grid grid-cols-4 gap-3">
        {(["critical", "high", "medium", "low"] as const).map((sev) => {
          const colors: Record<string, { bg: string; border: string; text: string; dot: string }> = {
            critical: { bg: "bg-red-500/5", border: "border-red-500/20", text: "text-red-400", dot: "bg-red-500" },
            high: { bg: "bg-amber-500/5", border: "border-amber-500/20", text: "text-amber-400", dot: "bg-amber-500" },
            medium: { bg: "bg-blue-500/5", border: "border-blue-500/20", text: "text-blue-400", dot: "bg-blue-500" },
            low: { bg: "bg-green-500/5", border: "border-green-500/20", text: "text-green-400", dot: "bg-green-500" },
          };
          const c = colors[sev];
          return (
            <button
              key={sev}
              onClick={() => setFilterSeverity(filterSeverity === sev ? "" : sev)}
              className={`card p-4 text-left transition-all ${filterSeverity === sev ? `${c.bg} ${c.border} ring-1 ring-inset` : "hover:bg-white/[0.02]"}`}
              style={filterSeverity === sev ? { borderColor: c.dot } : {}}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">{sev}</span>
                <span className={`w-2 h-2 rounded-full ${c.dot} ${sev === "critical" ? "animate-pulse" : ""}`} />
              </div>
              <div className={`text-3xl font-bold tabular-nums ${c.text}`}>{counts[sev] || 0}</div>
              <div className="text-[10px] text-slate-600 mt-1">{sev === "critical" ? "Immediate action" : sev === "high" ? "Active mitigation" : sev === "medium" ? "Monitor closely" : "Watch list"}</div>
            </button>
          );
        })}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-2 rounded-lg bg-[#111827] border border-[#1E293B] text-sm text-slate-300 focus:outline-none"
        >
          <option value="">All Mitigation Statuses</option>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="mitigated">Mitigated</option>
          <option value="accepted">Accepted</option>
        </select>
        {(filterSeverity || filterStatus) && (
          <button
            onClick={() => { setFilterSeverity(""); setFilterStatus(""); }}
            className="text-xs text-slate-500 hover:text-white transition-colors"
          >
            Clear filters
          </button>
        )}
        <span className="ml-auto text-xs text-slate-500">
          Showing {filtered.length} of {risks.length} risks
        </span>
      </div>

      {/* Risk Cards */}
      <div className="space-y-3">
        {filtered.map((risk) => (
          <div key={risk.id} className="card overflow-hidden">
            {/* Header Row */}
            <div
              className="px-5 py-4 flex items-start gap-4 cursor-pointer hover:bg-white/[0.02] transition-colors"
              onClick={() => setExpandedRisk(expandedRisk === risk.id ? null : risk.id)}
            >
              <SeverityBadge severity={risk.severity} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="text-sm font-semibold text-white">{risk.category}</h3>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 capitalize font-medium">
                    {risk.mitigation_status.replace(/_/g, " ")}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                  {risk.description}
                </p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-amber-400/60 bg-amber-500/5 px-2 py-0.5 rounded">
                    {WORKSTREAM_SHORT[risk.related_workstream] || "—"}
                  </span>
                </div>
                {risk.owner_name && (
                  <div className="text-[11px] text-slate-500 mt-1">{risk.owner_name}</div>
                )}
              </div>
              <span className="text-slate-600 text-xs mt-1">{expandedRisk === risk.id ? "▾" : "▸"}</span>
            </div>

            {/* Expanded Detail */}
            {expandedRisk === risk.id && (
              <div className="px-5 py-5 bg-[#0A0F1A] border-t border-[#1E293B] space-y-5 animate-fade-in">
                {/* Full description */}
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2">Risk Description</div>
                  <p className="text-sm text-slate-300 leading-relaxed">{risk.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  {/* Indicators */}
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2">Detection Indicators</div>
                    <div className="space-y-1.5">
                      {risk.indicators.map((ind, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500/50 mt-1.5 flex-shrink-0" />
                          <span className="text-slate-400">{ind}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Mitigations */}
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2">Mitigation Actions</div>
                    <div className="space-y-1.5">
                      {risk.mitigations.map((mit, i) => {
                        const isComplete = mit.includes("COMPLETE");
                        const isInProgress = mit.includes("IN PROGRESS");
                        return (
                          <div key={i} className="flex items-start gap-2 text-xs">
                            <span className={`w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center mt-0.5 ${
                              isComplete ? "bg-emerald-600 border-emerald-500" : isInProgress ? "border-blue-500" : "border-slate-600"
                            }`}>
                              {isComplete && <span className="text-white text-[8px]">✓</span>}
                              {isInProgress && <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
                            </span>
                            <span className={`${isComplete ? "text-slate-500 line-through" : "text-slate-300"}`}>
                              {mit.replace(" — COMPLETE", "").replace(" — IN PROGRESS", "")}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Related items */}
                <div className="flex items-center gap-4 pt-2 border-t border-[#1E293B]/50">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Related Checklist Items:</div>
                  <div className="flex gap-2">
                    {(risk.related_checklist_items || []).map((item: string) => (
                      <span key={item} className="text-[10px] font-mono text-blue-400/70 bg-blue-500/10 px-2 py-0.5 rounded">
                        {item}
                      </span>
                    ))}
                  </div>
                  {risk.detected_at && (
                    <span className="ml-auto text-[10px] text-slate-600">
                      Detected: {new Date(risk.detected_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
