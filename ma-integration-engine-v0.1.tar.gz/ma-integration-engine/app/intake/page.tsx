"use client";

import { useState, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { SeverityBadge, ProgressBar } from "@/components/ui";
import {
  DEAL_STRUCTURE_LABELS,
  INTEGRATION_MODEL_LABELS,
  INDUSTRY_SECTORS,
  JURISDICTIONS,
  SHARED_SERVICES,
  DEAL_VALUE_RANGES,
  LEGAL_ENTITY_RANGES,
  GAAP_FRAMEWORKS,
  ERP_SYSTEMS,
  BUYER_MATURITY_LEVELS,
  WORKSTREAM_SHORT,
  PHASE_LABELS,
} from "@/lib/types";
import { runDecisionCascade, type IntakeState } from "@/lib/cascade";
import type { DealStructure, IntegrationModel, WorkstreamScope } from "@/lib/types";

const EMPTY_INTAKE: IntakeState = {
  deal_structure: null,
  integration_model: null,
  target_close_date: null,
  cross_border: false,
  cross_border_jurisdictions: [],
  tsa_required: null,
  industry_sector: null,
  shared_services_transfer: [],
  deal_value_range: null,
  target_legal_entities: null,
  target_gaap_framework: null,
  target_erp_system: null,
  buyer_ma_maturity: null,
};

const SCOPE_COLORS: Record<WorkstreamScope, string> = {
  full_scope: "#059669",
  partial: "#2563EB",
  reduced: "#D97706",
  review_only: "#94A3B8",
  conditional: "#8B5CF6",
  minimal: "#64748B",
  not_applicable: "#334155",
};

const SCOPE_LABELS: Record<WorkstreamScope, string> = {
  full_scope: "Full Scope",
  partial: "Partial",
  reduced: "Reduced",
  review_only: "Review Only",
  conditional: "Conditional",
  minimal: "Minimal",
  not_applicable: "N/A",
};

export default function IntakePage() {
  const router = useRouter();
  const [intake, setIntake] = useState<IntakeState>(EMPTY_INTAKE);
  const [activeTier, setActiveTier] = useState(1);
  const [dealName, setDealName] = useState("");
  const [codeName, setCodeName] = useState("");
  const [showCascade, setShowCascade] = useState(true);

  const update = useCallback((field: keyof IntakeState, value: any) => {
    setIntake((prev) => ({ ...prev, [field]: value }));
  }, []);

  const toggleJurisdiction = useCallback((j: string) => {
    setIntake((prev) => {
      const jurs = prev.cross_border_jurisdictions.includes(j)
        ? prev.cross_border_jurisdictions.filter((x) => x !== j)
        : [...prev.cross_border_jurisdictions, j];
      return { ...prev, cross_border_jurisdictions: jurs, cross_border: jurs.length > 0 };
    });
  }, []);

  const toggleService = useCallback((s: string) => {
    setIntake((prev) => {
      const svcs = prev.shared_services_transfer.includes(s)
        ? prev.shared_services_transfer.filter((x) => x !== s)
        : [...prev.shared_services_transfer, s];
      return { ...prev, shared_services_transfer: svcs };
    });
  }, []);

  // Live cascade computation
  const cascade = useMemo(() => runDecisionCascade(intake), [intake]);

  const handleSubmit = () => {
    // In production: POST to /api/intake
    // For demo: navigate to dashboard with demo ID
    router.push("/deal/demo");
  };

  return (
    <div className="min-h-screen bg-[#0C1220]">
      {/* Header */}
      <header className="border-b border-[#1E293B] px-8 py-5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => router.push("/")} className="text-slate-500 hover:text-white transition-colors text-sm">
              ← Back
            </button>
            <div className="w-px h-5 bg-[#1E293B]" />
            <div>
              <h1 className="text-lg font-semibold text-white" style={{ fontFamily: "var(--font-display)" }}>New Deal Intake</h1>
              <p className="text-[11px] text-slate-500">Configure deal parameters to generate integration workflow</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-slate-500">Intake Completeness</div>
              <div className="flex items-center gap-2 mt-1">
                <ProgressBar value={cascade.completionScore} max={100} size="sm" />
                <span className="text-xs font-bold text-slate-300 tabular-nums w-8">{cascade.completionScore}%</span>
              </div>
            </div>
            <button
              onClick={handleSubmit}
              disabled={!cascade.tier1Complete}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                cascade.tier1Complete
                  ? "bg-gradient-to-r from-amber-600 to-amber-700 text-white hover:from-amber-500 hover:to-amber-600 shadow-lg shadow-amber-900/20"
                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
              }`}
            >
              Generate Workflow →
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-8 py-6">
        <div className="flex gap-6">
          {/* ═══════════ LEFT: INTAKE FORM ═══════════ */}
          <div className="flex-1 space-y-5 min-w-0">
            {/* Deal Identity */}
            <div className="card p-5">
              <h2 className="text-sm font-semibold text-white mb-4">Deal Identity</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-1.5 block">Deal Name <span className="text-red-400">*</span></label>
                  <input
                    type="text"
                    value={dealName}
                    onChange={(e) => setDealName(e.target.value)}
                    placeholder="e.g., Acme Corp Acquisition"
                    className="w-full px-3 py-2.5 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-1.5 block">Code Name</label>
                  <input
                    type="text"
                    value={codeName}
                    onChange={(e) => setCodeName(e.target.value)}
                    placeholder="e.g., Project Meridian"
                    className="w-full px-3 py-2.5 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50 transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Tier Tabs */}
            <div className="flex gap-1 bg-[#111827] rounded-lg p-1 border border-[#1E293B]">
              {[
                { tier: 1, label: "Tier 1: Gate Fields", required: true, complete: cascade.tier1Complete },
                { tier: 2, label: "Tier 2: Configuration", required: false, complete: cascade.tier2Complete },
                { tier: 3, label: "Tier 3: Enrichment", required: false, complete: cascade.tier3Complete },
              ].map((t) => (
                <button
                  key={t.tier}
                  onClick={() => setActiveTier(t.tier)}
                  className={`flex-1 px-4 py-2.5 rounded-md text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                    activeTier === t.tier
                      ? "bg-white/[0.08] text-white"
                      : "text-slate-500 hover:text-slate-300"
                  }`}
                >
                  {t.complete && <span className="w-4 h-4 rounded-full bg-emerald-600 flex items-center justify-center text-white text-[8px]">✓</span>}
                  {!t.complete && t.required && <span className="w-4 h-4 rounded-full border-2 border-amber-500/50 flex items-center justify-center text-amber-400 text-[8px]">!</span>}
                  {!t.complete && !t.required && <span className="w-4 h-4 rounded-full border border-slate-600" />}
                  {t.label}
                </button>
              ))}
            </div>

            {/* ═══ TIER 1: Gate Fields ═══ */}
            {activeTier === 1 && (
              <div className="space-y-4 animate-fade-in">
                <div className="card p-5 space-y-5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-white">Gate Fields</h2>
                    <span className="text-[10px] text-amber-400 font-medium">Required to generate workflow</span>
                  </div>

                  {/* Deal Structure */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">
                      Deal Structure <span className="text-red-400">*</span>
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(DEAL_STRUCTURE_LABELS).map(([key, label]) => (
                        <button
                          key={key}
                          onClick={() => update("deal_structure", key as DealStructure)}
                          className={`px-3 py-3 rounded-lg text-xs text-left transition-all border ${
                            intake.deal_structure === key
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600 hover:text-slate-300"
                          }`}
                        >
                          <div className="font-semibold">{label}</div>
                          {key === "carve_out_divestiture" && (
                            <div className="text-[10px] text-slate-600 mt-0.5">Triggers full TSA workstream</div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Integration Model */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">
                      Integration Model <span className="text-red-400">*</span>
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.entries(INTEGRATION_MODEL_LABELS).map(([key, label]) => (
                        <button
                          key={key}
                          onClick={() => update("integration_model", key as IntegrationModel)}
                          className={`px-3 py-3 rounded-lg text-xs text-center transition-all border ${
                            intake.integration_model === key
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                          }`}
                        >
                          <div className="font-semibold">{label}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Close Date */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-1.5 block">
                      Target Close Date <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="date"
                      value={intake.target_close_date || ""}
                      onChange={(e) => update("target_close_date", e.target.value || null)}
                      className="px-3 py-2.5 rounded-lg bg-[#0D1117] border border-[#1E293B] text-sm text-white focus:outline-none focus:border-amber-500/50 transition-colors"
                    />
                  </div>

                  {/* Cross-Border */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">
                      Cross-Border Jurisdictions
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {JURISDICTIONS.map((j) => (
                        <button
                          key={j}
                          onClick={() => toggleJurisdiction(j)}
                          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all border ${
                            intake.cross_border_jurisdictions.includes(j)
                              ? "bg-blue-500/15 border-blue-500/40 text-blue-300"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-500 hover:border-slate-600"
                          }`}
                        >
                          {j}
                        </button>
                      ))}
                    </div>
                    {intake.cross_border && (
                      <p className="text-[10px] text-blue-400 mt-2">
                        {intake.cross_border_jurisdictions.length} jurisdiction(s) selected — cross-border regulatory overlay will be applied
                      </p>
                    )}
                  </div>

                  {/* TSA Required */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">
                      TSA Required <span className="text-red-400">*</span>
                    </label>
                    <div className="flex gap-2">
                      {(["yes", "no", "tbd"] as const).map((val) => (
                        <button
                          key={val}
                          onClick={() => update("tsa_required", val)}
                          className={`px-4 py-2.5 rounded-lg text-xs font-semibold transition-all border capitalize ${
                            intake.tsa_required === val
                              ? val === "yes" ? "bg-amber-500/10 border-amber-500/40 text-amber-200" :
                                val === "no" ? "bg-slate-500/10 border-slate-500/40 text-slate-300" :
                                "bg-purple-500/10 border-purple-500/40 text-purple-300"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-500 hover:border-slate-600"
                          }`}
                        >
                          {val === "tbd" ? "To Be Determined" : val}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ═══ TIER 2: Configuration ═══ */}
            {activeTier === 2 && (
              <div className="space-y-4 animate-fade-in">
                <div className="card p-5 space-y-5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-white">Configuration Fields</h2>
                    <span className="text-[10px] text-slate-400">Refine workflow scoping</span>
                  </div>

                  {/* Industry Sector */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Industry / Sector</label>
                    <div className="grid grid-cols-4 gap-2">
                      {INDUSTRY_SECTORS.map((s) => (
                        <button
                          key={s}
                          onClick={() => update("industry_sector", s)}
                          className={`px-3 py-2.5 rounded-lg text-xs text-center transition-all border ${
                            intake.industry_sector === s
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Shared Services */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Shared Services Transferring to Buyer</label>
                    <div className="flex flex-wrap gap-2">
                      {SHARED_SERVICES.map((s) => (
                        <button
                          key={s}
                          onClick={() => toggleService(s)}
                          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all border ${
                            intake.shared_services_transfer.includes(s)
                              ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-500 hover:border-slate-600"
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-600 mt-1">
                      Services transferring to buyer will grey out corresponding TSA line items
                    </p>
                  </div>

                  {/* Deal Value + Entities */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Deal Value Range</label>
                      <div className="space-y-1.5">
                        {DEAL_VALUE_RANGES.map((v) => (
                          <button
                            key={v}
                            onClick={() => update("deal_value_range", v)}
                            className={`w-full px-3 py-2 rounded-lg text-xs text-left transition-all border ${
                              intake.deal_value_range === v
                                ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                                : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                            }`}
                          >
                            {v}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Target Legal Entities</label>
                      <div className="space-y-1.5">
                        {LEGAL_ENTITY_RANGES.map((v) => (
                          <button
                            key={v}
                            onClick={() => update("target_legal_entities", v)}
                            className={`w-full px-3 py-2 rounded-lg text-xs text-left transition-all border ${
                              intake.target_legal_entities === v
                                ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                                : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                            }`}
                          >
                            {v} {v === "6–20" || v === "20+" ? "— full consolidation" : ""}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ═══ TIER 3: Enrichment ═══ */}
            {activeTier === 3 && (
              <div className="space-y-4 animate-fade-in">
                <div className="card p-5 space-y-5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold text-white">Enrichment Fields</h2>
                    <span className="text-[10px] text-slate-400">Improve AI guidance quality</span>
                  </div>

                  {/* GAAP */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Target GAAP Framework</label>
                    <div className="grid grid-cols-4 gap-2">
                      {GAAP_FRAMEWORKS.map((g) => (
                        <button
                          key={g}
                          onClick={() => update("target_gaap_framework", g)}
                          className={`px-3 py-2.5 rounded-lg text-xs text-center transition-all border ${
                            intake.target_gaap_framework === g
                              ? g !== "US GAAP" ? "bg-amber-500/10 border-amber-500/40 text-amber-200" : "bg-emerald-500/10 border-emerald-500/40 text-emerald-300"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                          }`}
                        >
                          {g}
                          {g !== "US GAAP" && intake.target_gaap_framework === g && (
                            <div className="text-[9px] text-amber-400/70 mt-0.5">Conversion required</div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* ERP */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Target ERP System</label>
                    <div className="grid grid-cols-3 gap-2">
                      {ERP_SYSTEMS.map((e) => (
                        <button
                          key={e}
                          onClick={() => update("target_erp_system", e)}
                          className={`px-3 py-2 rounded-lg text-xs text-center transition-all border ${
                            intake.target_erp_system === e
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                          }`}
                        >
                          {e}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Buyer Maturity */}
                  <div>
                    <label className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mb-2 block">Buyer M&A Maturity</label>
                    <div className="grid grid-cols-2 gap-2">
                      {BUYER_MATURITY_LEVELS.map((m) => (
                        <button
                          key={m}
                          onClick={() => update("buyer_ma_maturity", m)}
                          className={`px-3 py-3 rounded-lg text-xs text-left transition-all border ${
                            intake.buyer_ma_maturity === m
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-200"
                              : "bg-[#0D1117] border-[#1E293B] text-slate-400 hover:border-slate-600"
                          }`}
                        >
                          <div className="font-semibold">{m}</div>
                          {m === "First acquisition" && <div className="text-[10px] text-slate-600 mt-0.5">Detailed guidance enabled</div>}
                          {m.includes("Serial") && <div className="text-[10px] text-slate-600 mt-0.5">Streamlined views</div>}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ═══════════ RIGHT: LIVE CASCADE PREVIEW ═══════════ */}
          <div className="w-[400px] flex-shrink-0 space-y-4">
            <div className="sticky top-6 space-y-4">
              {/* Cascade Header */}
              <div className="card">
                <div className="px-4 py-3 border-b border-[#1E293B] flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">Decision Cascade Preview</span>
                  <span className="text-[10px] text-slate-500 tabular-nums">{cascade.totalActiveItems} items active</span>
                </div>

                {/* Workstream Activation Matrix */}
                <div className="p-3 space-y-1 max-h-[340px] overflow-y-auto">
                  {cascade.workstreams.map((ws) => (
                    <div key={ws.workstream} className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-white/[0.02]">
                      <span className="text-[9px] font-bold w-7 text-amber-400/50">{WORKSTREAM_SHORT[ws.workstream]}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-slate-300 truncate">{ws.workstream}</span>
                        </div>
                      </div>
                      <span
                        className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded"
                        style={{
                          color: SCOPE_COLORS[ws.scope],
                          background: SCOPE_COLORS[ws.scope] + "15",
                        }}
                      >
                        {SCOPE_LABELS[ws.scope]}
                      </span>
                      <span className="text-[10px] text-slate-500 tabular-nums w-7 text-right">{ws.itemCount}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Risk Flags */}
              {cascade.riskFlags.length > 0 && (
                <div className="card">
                  <div className="px-4 py-3 border-b border-[#1E293B]">
                    <span className="text-xs font-semibold text-white">Auto-Detected Risks</span>
                  </div>
                  <div className="p-3 space-y-2 max-h-[250px] overflow-y-auto">
                    {cascade.riskFlags.map((risk, i) => (
                      <div key={i} className="px-3 py-2.5 rounded-lg bg-[#0A0F1A] border border-[#1E293B]">
                        <div className="flex items-center gap-2 mb-1">
                          <SeverityBadge severity={risk.severity} />
                          <span className="text-[11px] font-semibold text-white">{risk.category}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-relaxed">{risk.description}</p>
                        <p className="text-[9px] text-slate-600 mt-1">Source: {risk.source}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Regulatory Filings */}
              {cascade.regulatoryFilings.length > 0 && (
                <div className="card">
                  <div className="px-4 py-3 border-b border-[#1E293B]">
                    <span className="text-xs font-semibold text-white">Regulatory Filings Required</span>
                  </div>
                  <div className="p-3 space-y-2">
                    {cascade.regulatoryFilings.map((filing, i) => (
                      <div key={i} className="flex items-start gap-2 px-2 py-2">
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${filing.required ? "bg-red-500/15 text-red-400" : "bg-amber-500/15 text-amber-400"}`}>
                          {filing.required ? "REQUIRED" : "ASSESS"}
                        </span>
                        <div className="min-w-0">
                          <div className="text-[11px] font-semibold text-slate-300">{filing.name}</div>
                          <div className="text-[10px] text-slate-500">{filing.jurisdiction} · {filing.estimatedTimeline}</div>
                          <div className="text-[9px] text-slate-600 mt-0.5">{filing.trigger}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Timeline Preview */}
              {cascade.milestones.length > 0 && (
                <div className="card p-4">
                  <div className="text-xs font-semibold text-white mb-3">Integration Timeline</div>
                  <div className="space-y-1.5">
                    {cascade.milestones.map((ms) => {
                      const daysOut = Math.ceil((new Date(ms.date).getTime() - Date.now()) / 86400000);
                      return (
                        <div key={ms.phase} className="flex items-center gap-3 text-[11px]">
                          <span className="w-14 text-slate-500 text-right tabular-nums">{PHASE_LABELS[ms.phase]}</span>
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                          <span className="text-slate-400 flex-1">{new Date(ms.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                          <span className={`tabular-nums ${daysOut < 30 ? "text-red-400" : daysOut < 60 ? "text-amber-400" : "text-slate-500"}`}>
                            {daysOut > 0 ? `${daysOut}d` : daysOut === 0 ? "Today" : `${Math.abs(daysOut)}d ago`}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
