import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "M&A Integration Engine",
  description: "AI-Driven Post-Merger Integration Platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-[#0C1220]">
        {children}
      </body>
    </html>
  );
}
