// ============================================================
// M&A Integration Engine - Shared Types
// Maps to PRD v1.6 data model
// ============================================================

export type DealStructure =
  | "stock_purchase"
  | "asset_purchase"
  | "merger_forward_triangular"
  | "merger_reverse_triangular"
  | "merger_direct"
  | "f_reorganization"
  | "carve_out_divestiture";

export type IntegrationModel =
  | "fully_integrated"
  | "hybrid_selective"
  | "standalone_platform";

export type DealStage =
  | "stage_1_intake"
  | "stage_2_review_assign"
  | "stage_3_execute_track"
  | "stage_4_report_govern"
  | "stage_5_close_adapt";

export type ChecklistStatus =
  | "not_started"
  | "in_progress"
  | "blocked"
  | "complete"
  | "not_applicable";

export type PriorityLevel = "critical" | "high" | "medium" | "low";

export type RiskSeverity = "critical" | "high" | "medium" | "low" | "resolved";

export type MilestonePhase =
  | "pre_close"
  | "day_1"
  | "day_30"
  | "day_60"
  | "day_90"
  | "day_180"
  | "year_1";

export type WorkstreamScope =
  | "full_scope"
  | "partial"
  | "reduced"
  | "review_only"
  | "conditional"
  | "minimal"
  | "not_applicable";

// ============================================================
// DISPLAY HELPERS
// ============================================================

export const DEAL_STRUCTURE_LABELS: Record<DealStructure, string> = {
  stock_purchase: "Stock / Share Purchase",
  asset_purchase: "Asset Purchase",
  merger_forward_triangular: "Forward Triangular Merger",
  merger_reverse_triangular: "Reverse Triangular Merger",
  merger_direct: "Direct Statutory Merger",
  f_reorganization: "F-Reorganization",
  carve_out_divestiture: "Carve-Out / Divestiture",
};

export const INTEGRATION_MODEL_LABELS: Record<IntegrationModel, string> = {
  fully_integrated: "Fully Integrated",
  hybrid_selective: "Hybrid (Selective)",
  standalone_platform: "Standalone / Platform Add-On",
};

export const STAGE_LABELS: Record<DealStage, string> = {
  stage_1_intake: "Stage 1: Intake & Configure",
  stage_2_review_assign: "Stage 2: Review & Assign",
  stage_3_execute_track: "Stage 3: Execute & Track",
  stage_4_report_govern: "Stage 4: Report & Govern",
  stage_5_close_adapt: "Stage 5: Close & Adapt",
};

export const STATUS_LABELS: Record<ChecklistStatus, string> = {
  not_started: "Not Started",
  in_progress: "In Progress",
  blocked: "Blocked",
  complete: "Complete",
  not_applicable: "N/A",
};

export const STATUS_COLORS: Record<ChecklistStatus, string> = {
  not_started: "#64748B",
  in_progress: "#2563EB",
  blocked: "#9333EA",
  complete: "#059669",
  not_applicable: "#94A3B8",
};

export const SEVERITY_COLORS: Record<RiskSeverity, string> = {
  critical: "#DC2626",
  high: "#D97706",
  medium: "#2563EB",
  low: "#059669",
  resolved: "#94A3B8",
};

export const PHASE_LABELS: Record<MilestonePhase, string> = {
  pre_close: "Pre-Close",
  day_1: "Day 1",
  day_30: "Day 30",
  day_60: "Day 60",
  day_90: "Day 90",
  day_180: "Day 180",
  year_1: "Year 1",
};

export const WORKSTREAM_SHORT: Record<string, string> = {
  "TSA Assessment & Exit": "TSA",
  "Consolidation & Reporting": "CON",
  "Operational Accounting": "OPS",
  "Internal Controls & SOX": "ICX",
  "Income Tax & Compliance": "TAX",
  "Treasury & Banking": "TRE",
  "FP&A & Baselining": "FPA",
  "Cybersecurity & Data Privacy": "CYB",
  "ESG & Sustainability": "ESG",
  "Integration Budget & PMO": "PMO",
  "Facilities & Real Estate": "FAC",
  "Insurance & Pensions": "INS",
};

export const ALL_WORKSTREAMS = Object.keys(WORKSTREAM_SHORT);

export const INDUSTRY_SECTORS = [
  "Technology",
  "Healthcare / Pharma",
  "Financial Services",
  "Defense / Aerospace",
  "Manufacturing",
  "Energy",
  "Consumer / Retail",
  "Other",
];

export const JURISDICTIONS = [
  "US",
  "EU (Germany)",
  "EU (France)",
  "EU (Netherlands)",
  "UK",
  "APAC (Japan)",
  "APAC (Australia)",
  "APAC (Singapore)",
  "LatAm (Brazil)",
  "LatAm (Mexico)",
  "Canada",
  "Other",
];

export const SHARED_SERVICES = [
  "AR/AP",
  "Payroll",
  "GL Close",
  "Tax Filing",
  "Treasury",
  "IT Infrastructure",
  "HR Admin",
];

export const DEAL_VALUE_RANGES = [
  "<$50M",
  "$50M–$250M",
  "$250M–$1B",
  "$1B–$5B",
  ">$5B",
];

export const LEGAL_ENTITY_RANGES = ["1–5", "6–20", "20+", "Unknown"];

export const GAAP_FRAMEWORKS = ["US GAAP", "IFRS", "Local GAAP", "Multiple"];

export const ERP_SYSTEMS = [
  "SAP S/4HANA",
  "SAP ECC",
  "Oracle Cloud",
  "Oracle EBS",
  "NetSuite",
  "Workday",
  "QuickBooks",
  "Custom / Legacy",
  "Unknown",
];

export const BUYER_MATURITY_LEVELS = [
  "First acquisition",
  "Occasional (<5 deals)",
  "Serial acquirer (5+ deals)",
  "PE platform / roll-up",
];

// ============================================================
// INTERFACES
// ============================================================

export interface Deal {
  id: string;
  org_id: string;
  name: string;
  code_name: string;
  stage: DealStage;
  is_active: boolean;
  created_at: string;
}

export interface DealIntake {
  id: string;
  deal_id: string;
  deal_structure: DealStructure | null;
  integration_model: IntegrationModel | null;
  target_close_date: string | null;
  cross_border: boolean;
  cross_border_jurisdictions: string[];
  tsa_required: string | null;
  industry_sector: string | null;
  shared_services_transfer: string[];
  deal_value_range: string | null;
  target_legal_entities: string | null;
  target_gaap_framework: string | null;
  target_erp_system: string | null;
  buyer_ma_maturity: string | null;
  tier_1_complete: boolean;
  tier_2_complete: boolean;
  tier_3_complete: boolean;
}

export interface ChecklistItem {
  id: string;
  deal_id: string;
  source_item_id: string;
  workstream: string;
  section: string;
  description: string;
  status: ChecklistStatus;
  phase: MilestonePhase;
  priority: PriorityLevel;
  milestone_date: string;
  owner_id: string | null;
  owner_name: string | null;
  is_active: boolean;
  notes: unknown[];
  blocked_reason: string | null;
}

export interface RiskItem {
  id: string;
  deal_id: string;
  category: string;
  description: string;
  severity: RiskSeverity;
  indicators: string[];
  mitigations: string[];
  mitigation_status: string;
  related_workstream: string;
  owner_name: string | null;
}

export interface WorkstreamProgress {
  workstream: string;
  total_items: number;
  complete: number;
  in_progress: number;
  blocked: number;
  not_started: number;
  completion_pct: number;
}

export interface Milestone {
  id: string;
  phase: MilestonePhase;
  label: string;
  target_date: string;
  status: string;
}
