import { neon, neonConfig } from "@neondatabase/serverless";

// Enable connection pooling for serverless
neonConfig.fetchConnectionCache = true;

export function getDb() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable is not set");
  }
  return neon(process.env.DATABASE_URL);
}

// Helper for typed queries
export async function query<T = Record<string, unknown>>(
  sql: string,
  params?: unknown[]
): Promise<T[]> {
  const db = getDb();
  const result = await db(sql, params);
  return result as T[];
}

// Transaction helper
export async function transaction<T>(
  fn: (sql: ReturnType<typeof neon>) => Promise<T>
): Promise<T> {
  const db = getDb();
  return fn(db);
}
