/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#FDF8F0",
          100: "#FAF0DE",
          200: "#F2DDB8",
          300: "#E8C78E",
          400: "#D4A563",
          500: "#B8863E",
          600: "#96692E",
          700: "#6E4D22",
          800: "#4A3317",
          900: "#2C1F0E",
          950: "#1A120A",
        },
        sand: {
          50: "#FAFAF7",
          100: "#F5F5EE",
          200: "#E8E8DD",
          300: "#D4D4C4",
          400: "#AEAE96",
          500: "#8A8A6E",
          600: "#6B6B52",
          700: "#52523E",
          800: "#3A3A2C",
          900: "#26261D",
          950: "#171712",
        },
        navy: {
          50: "#F0F4F8",
          100: "#D9E2EC",
          200: "#BCCCDC",
          300: "#9FB3C8",
          400: "#829AB1",
          500: "#627D98",
          600: "#486581",
          700: "#334E68",
          800: "#243B53",
          900: "#102A43",
          950: "#0A1929",
        },
        status: {
          success: "#059669",
          warning: "#D97706",
          danger: "#DC2626",
          info: "#2563EB",
          blocked: "#9333EA",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "Menlo", "monospace"],
      },
      animation: {
        "fade-in": "fadeIn 0.5s ease-out",
        "slide-up": "slideUp 0.4s ease-out",
        "pulse-soft": "pulseSoft 2s ease-in-out infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        pulseSoft: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.7" },
        },
      },
    },
  },
  plugins: [],
};
