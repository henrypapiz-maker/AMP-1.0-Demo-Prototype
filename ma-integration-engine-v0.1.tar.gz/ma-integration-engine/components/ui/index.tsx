"use client";

import { clsx } from "clsx";
import {
  STATUS_LABELS,
  STATUS_COLORS,
  SEVERITY_COLORS,
  PHASE_LABELS,
  WORKSTREAM_SHORT,
  type ChecklistStatus,
  type RiskSeverity,
  type PriorityLevel,
  type MilestonePhase,
} from "@/lib/types";

// ============================================================
// STATUS BADGE
// ============================================================
export function StatusBadge({ status }: { status: ChecklistStatus }) {
  const colorMap: Record<ChecklistStatus, string> = {
    not_started: "bg-slate-500/15 text-slate-400",
    in_progress: "bg-blue-500/15 text-blue-400",
    blocked: "bg-purple-500/15 text-purple-400",
    complete: "bg-emerald-500/15 text-emerald-400",
    not_applicable: "bg-slate-500/10 text-slate-500",
  };

  return (
    <span className={clsx("inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wide", colorMap[status])}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: STATUS_COLORS[status] }} />
      {STATUS_LABELS[status]}
    </span>
  );
}

// ============================================================
// SEVERITY BADGE
// ============================================================
export function SeverityBadge({ severity }: { severity: RiskSeverity }) {
  const colorMap: Record<RiskSeverity, string> = {
    critical: "bg-red-500/15 text-red-400 border-red-500/20",
    high: "bg-amber-500/15 text-amber-400 border-amber-500/20",
    medium: "bg-blue-500/15 text-blue-400 border-blue-500/20",
    low: "bg-green-500/15 text-green-400 border-green-500/20",
    resolved: "bg-slate-500/10 text-slate-500 border-slate-500/20",
  };

  return (
    <span className={clsx("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider border", colorMap[severity])}>
      {severity === "critical" && <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />}
      {severity}
    </span>
  );
}

// ============================================================
// PRIORITY BADGE
// ============================================================
export function PriorityBadge({ priority }: { priority: PriorityLevel }) {
  const colorMap: Record<PriorityLevel, string> = {
    critical: "text-red-400",
    high: "text-amber-400",
    medium: "text-blue-400",
    low: "text-slate-400",
  };
  const dots: Record<PriorityLevel, number> = { critical: 4, high: 3, medium: 2, low: 1 };

  return (
    <span className={clsx("inline-flex items-center gap-1 text-[11px] font-semibold capitalize", colorMap[priority])}>
      <span className="flex gap-0.5">
        {Array.from({ length: 4 }).map((_, i) => (
          <span
            key={i}
            className={clsx("w-1 h-3 rounded-sm", i < dots[priority] ? "opacity-100" : "opacity-20")}
            style={{ background: i < dots[priority] ? SEVERITY_COLORS[priority] : "#475569" }}
          />
        ))}
      </span>
      {priority}
    </span>
  );
}

// ============================================================
// PHASE BADGE
// ============================================================
export function PhaseBadge({ phase }: { phase: MilestonePhase }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded bg-slate-700/50 text-[10px] font-semibold text-slate-300 uppercase tracking-wider">
      {PHASE_LABELS[phase]}
    </span>
  );
}

// ============================================================
// WORKSTREAM TAG
// ============================================================
export function WorkstreamTag({ name }: { name: string }) {
  const short = WORKSTREAM_SHORT[name] || name.slice(0, 3).toUpperCase();
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#1E293B] text-[10px] font-bold text-slate-300 uppercase tracking-wider">
      <span className="text-amber-400/70">{short}</span>
      <span className="hidden sm:inline text-slate-400 font-normal normal-case tracking-normal">{name}</span>
    </span>
  );
}

// ============================================================
// PROGRESS BAR
// ============================================================
export function ProgressBar({
  value,
  max,
  size = "md",
  showLabel = false,
  color,
}: {
  value: number;
  max: number;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  color?: string;
}) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  const heights = { sm: "h-1", md: "h-2", lg: "h-3" };
  const barColor = color || (pct >= 80 ? "#059669" : pct >= 50 ? "#2563EB" : pct >= 25 ? "#D97706" : "#64748B");

  return (
    <div className="flex items-center gap-2 w-full">
      <div className={clsx("flex-1 rounded-full overflow-hidden bg-slate-800", heights[size])}>
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{ width: `${pct}%`, background: barColor }}
        />
      </div>
      {showLabel && (
        <span className="text-[11px] font-semibold text-slate-400 tabular-nums w-10 text-right">{pct}%</span>
      )}
    </div>
  );
}

// ============================================================
// KPI CARD
// ============================================================
export function KPICard({
  label,
  value,
  subtitle,
  color,
  icon,
}: {
  label: string;
  value: string | number;
  subtitle?: string;
  color?: string;
  icon?: string;
}) {
  return (
    <div className="card p-4 flex flex-col gap-1 min-w-0">
      <div className="flex items-center justify-between">
        <span className="kpi-label">{label}</span>
        {icon && <span className="text-lg opacity-50">{icon}</span>}
      </div>
      <div className="kpi-value" style={{ color: color || "#F1F5F9" }}>{value}</div>
      {subtitle && <div className="text-[11px] text-slate-500">{subtitle}</div>}
    </div>
  );
}

// ============================================================
// EMPTY STATE
// ============================================================
export function EmptyState({ title, message }: { title: string; message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-4xl mb-3 opacity-30">◇</div>
      <div className="text-sm font-semibold text-slate-300 mb-1">{title}</div>
      <div className="text-xs text-slate-500 max-w-xs">{message}</div>
    </div>
  );
}

// ============================================================
// LOADING SKELETON
// ============================================================
export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={clsx("animate-pulse bg-slate-800 rounded", className)} />
  );
}

export function DashboardSkeleton() {
  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24" />)}
      </div>
      <Skeleton className="h-96" />
      <div className="grid grid-cols-2 gap-4">
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    </div>
  );
}
