"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { clsx } from "clsx";

const NAV_ITEMS = [
  { href: "", label: "PMO Dashboard", icon: "◉" },
  { href: "/checklist", label: "Checklist", icon: "☰" },
  { href: "/risks", label: "Risk Register", icon: "⚠" },
];

export function AppShell({
  children,
  dealId,
  dealName,
}: {
  children: React.ReactNode;
  dealId: string;
  dealName?: string;
}) {
  const pathname = usePathname();

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 bg-[#080E1A] border-r border-[#1E293B] flex flex-col">
        {/* Brand */}
        <div className="px-5 py-5 border-b border-[#1E293B]">
          <Link href="/" className="block">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500/80 to-amber-700/80 flex items-center justify-center text-white font-bold text-sm tracking-tight">
                M&A
              </div>
              <div>
                <div className="text-sm font-semibold text-white tracking-tight">Integration Engine</div>
                <div className="text-[10px] text-slate-500 uppercase tracking-widest">Finance · v0.1</div>
              </div>
            </div>
          </Link>
        </div>

        {/* Deal Info */}
        <div className="px-5 py-4 border-b border-[#1E293B]">
          <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Active Deal</div>
          <div className="text-sm font-semibold text-white">{dealName || "Project Meridian"}</div>
          <div className="text-xs text-slate-400 mt-0.5">Stage 3: Execute & Track</div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const fullHref = `/deal/${dealId}${item.href}`;
            const isActive = item.href === ""
              ? pathname === `/deal/${dealId}`
              : pathname?.startsWith(fullHref);

            return (
              <Link
                key={item.href}
                href={fullHref}
                className={clsx(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150",
                  isActive
                    ? "bg-white/[0.08] text-white font-medium"
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
                )}
              >
                <span className="text-base opacity-70">{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-[#1E293B]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-[10px] font-bold">SC</div>
            <div>
              <div className="text-xs text-white font-medium">Sarah Chen</div>
              <div className="text-[10px] text-slate-500">PMO Lead</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
