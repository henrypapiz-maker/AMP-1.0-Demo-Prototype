-- M&A Integration Engine - Database Schema v0.1
-- Target: Neon PostgreSQL
-- Maps to PRD v1.6 Section 2.5.4 Storage Model

-- ============================================================
-- EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================
CREATE TYPE deal_structure AS ENUM (
  'stock_purchase',
  'asset_purchase',
  'merger_forward_triangular',
  'merger_reverse_triangular',
  'merger_direct',
  'f_reorganization',
  'carve_out_divestiture'
);

CREATE TYPE integration_model AS ENUM (
  'fully_integrated',
  'hybrid_selective',
  'standalone_platform'
);

CREATE TYPE deal_stage AS ENUM (
  'stage_1_intake',
  'stage_2_review_assign',
  'stage_3_execute_track',
  'stage_4_report_govern',
  'stage_5_close_adapt'
);

CREATE TYPE checklist_status AS ENUM (
  'not_started',
  'in_progress',
  'blocked',
  'complete',
  'not_applicable'
);

CREATE TYPE priority_level AS ENUM (
  'critical',
  'high',
  'medium',
  'low'
);

CREATE TYPE risk_severity AS ENUM (
  'critical',
  'high',
  'medium',
  'low',
  'resolved'
);

CREATE TYPE milestone_phase AS ENUM (
  'pre_close',
  'day_1',
  'day_30',
  'day_60',
  'day_90',
  'day_180',
  'year_1'
);

CREATE TYPE workstream_scope AS ENUM (
  'full_scope',
  'partial',
  'reduced',
  'review_only',
  'conditional',
  'minimal',
  'not_applicable'
);

-- ============================================================
-- TABLE: organizations
-- ============================================================
CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: users (lightweight for v0 - no auth yet)
-- ============================================================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member', -- admin, pmo_lead, workstream_lead, member, viewer
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: deals
-- The core deal entity. Lifecycle stages tracked here.
-- ============================================================
CREATE TABLE deals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  org_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  code_name TEXT, -- "Project Meridian"
  stage deal_stage NOT NULL DEFAULT 'stage_1_intake',
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: deal_intake
-- PRD Section 2: 12 intake fields across 3 tiers
-- JSONB for flexibility + typed columns for indexed queries
-- ============================================================
CREATE TABLE deal_intake (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID UNIQUE REFERENCES deals(id) ON DELETE CASCADE,

  -- Tier 1: Gate Fields (required)
  deal_structure deal_structure,
  integration_model integration_model,
  target_close_date DATE,
  cross_border BOOLEAN,
  cross_border_jurisdictions TEXT[] DEFAULT '{}',
  tsa_required TEXT CHECK (tsa_required IN ('yes', 'no', 'tbd')),

  -- Tier 2: Configuration Fields
  industry_sector TEXT,
  shared_services_transfer TEXT[] DEFAULT '{}',
  deal_value_range TEXT,
  target_legal_entities TEXT,

  -- Tier 3: Enrichment Fields
  target_gaap_framework TEXT,
  target_erp_system TEXT,
  buyer_ma_maturity TEXT,

  -- Full intake payload for AI processing
  intake_payload JSONB DEFAULT '{}',

  -- Decision cascade output
  workstream_activation JSONB DEFAULT '{}',
  decision_cascade_log JSONB DEFAULT '[]',

  tier_1_complete BOOLEAN DEFAULT false,
  tier_2_complete BOOLEAN DEFAULT false,
  tier_3_complete BOOLEAN DEFAULT false,

  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: taxonomy_activities_master
-- PRD Section 2.5.4: 443-item Finance Readiness Checklist
-- Master taxonomy - org-wide, versioned
-- ============================================================
CREATE TABLE taxonomy_activities_master (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  item_id TEXT UNIQUE NOT NULL, -- FRC-0001 through FRC-0443
  workstream TEXT NOT NULL, -- 12 workstreams (L2)
  section TEXT NOT NULL, -- L3 taxonomy
  description TEXT NOT NULL,
  default_phase milestone_phase NOT NULL DEFAULT 'day_1',
  default_priority priority_level NOT NULL DEFAULT 'medium',
  dependencies TEXT[] DEFAULT '{}', -- array of item_ids
  tsa_relevant BOOLEAN DEFAULT false,
  cross_border_relevant BOOLEAN DEFAULT false,
  guidance_prompt TEXT, -- FR-13 embedded expertise
  scope_rules JSONB DEFAULT '{}', -- which deal structures activate this
  version TEXT NOT NULL DEFAULT '1.0',
  is_day1_critical BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for workstream queries
CREATE INDEX idx_taxonomy_workstream ON taxonomy_activities_master(workstream);
CREATE INDEX idx_taxonomy_phase ON taxonomy_activities_master(default_phase);
CREATE INDEX idx_taxonomy_item_id ON taxonomy_activities_master(item_id);

-- ============================================================
-- TABLE: deal_checklist_items
-- PRD Section 4.1: Per-deal instantiated checklist
-- ============================================================
CREATE TABLE deal_checklist_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  source_item_id TEXT REFERENCES taxonomy_activities_master(item_id),

  -- From master (can be overridden per-deal)
  workstream TEXT NOT NULL,
  section TEXT NOT NULL,
  description TEXT NOT NULL,

  -- Per-deal state (Section 4.2 Lifecycle State Machine)
  status checklist_status NOT NULL DEFAULT 'not_started',
  phase milestone_phase NOT NULL DEFAULT 'day_1',
  priority priority_level NOT NULL DEFAULT 'medium',
  milestone_date DATE,

  -- Assignment
  owner_id UUID REFERENCES users(id),
  owner_name TEXT,

  -- Deal-specific
  dependencies TEXT[] DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  scope workstream_scope DEFAULT 'full_scope',
  tsa_relevant BOOLEAN DEFAULT false,
  cross_border_flag BOOLEAN DEFAULT false,
  risk_indicators TEXT[] DEFAULT '{}',

  -- AI guidance (rules-first for MVP)
  guidance_prompt TEXT,
  ai_guidance_response JSONB,

  -- User input
  notes JSONB DEFAULT '[]',
  evidence_urls TEXT[] DEFAULT '{}',
  completion_evidence TEXT,

  -- Source tracking for taxonomy feedback loop
  source TEXT DEFAULT 'master', -- 'master' | 'deal_specific'
  source_version TEXT DEFAULT '1.0',

  -- Timestamps
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  blocked_at TIMESTAMPTZ,
  blocked_reason TEXT,
  last_status_change TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indices for dashboard queries
CREATE INDEX idx_checklist_deal ON deal_checklist_items(deal_id);
CREATE INDEX idx_checklist_status ON deal_checklist_items(deal_id, status);
CREATE INDEX idx_checklist_workstream ON deal_checklist_items(deal_id, workstream);
CREATE INDEX idx_checklist_phase ON deal_checklist_items(deal_id, phase);
CREATE INDEX idx_checklist_owner ON deal_checklist_items(owner_id);
CREATE INDEX idx_checklist_milestone ON deal_checklist_items(deal_id, milestone_date);

-- ============================================================
-- TABLE: taxonomy_risks_master
-- PRD Section 6: Risk taxonomy with detection rules
-- ============================================================
CREATE TABLE taxonomy_risks_master (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category TEXT NOT NULL,
  subcategory TEXT,
  description TEXT NOT NULL,
  indicators JSONB NOT NULL DEFAULT '[]', -- detection signals
  severity_rules JSONB NOT NULL DEFAULT '{}', -- JSON predicates
  mitigations JSONB NOT NULL DEFAULT '[]', -- suggested actions
  detection_logic TEXT, -- human-readable rule
  related_workstreams TEXT[] DEFAULT '{}',
  version TEXT DEFAULT '1.0',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: deal_risk_register
-- Per-deal instantiated risks
-- ============================================================
CREATE TABLE deal_risk_register (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  source_risk_id UUID REFERENCES taxonomy_risks_master(id),

  category TEXT NOT NULL,
  subcategory TEXT,
  description TEXT NOT NULL,
  severity risk_severity NOT NULL DEFAULT 'medium',
  indicators JSONB DEFAULT '[]',
  mitigations JSONB DEFAULT '[]',
  mitigation_status TEXT DEFAULT 'open', -- open, in_progress, mitigated, accepted
  related_workstream TEXT,
  related_checklist_items TEXT[] DEFAULT '{}',

  owner_id UUID REFERENCES users(id),
  owner_name TEXT,

  detected_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ,
  severity_history JSONB DEFAULT '[]',
  notes JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_risk_deal ON deal_risk_register(deal_id);
CREATE INDEX idx_risk_severity ON deal_risk_register(deal_id, severity);

-- ============================================================
-- TABLE: deal_workstream_config
-- Per-deal workstream scoping from decision cascade
-- ============================================================
CREATE TABLE deal_workstream_config (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  workstream TEXT NOT NULL,
  scope workstream_scope NOT NULL DEFAULT 'full_scope',
  total_items INTEGER DEFAULT 0,
  active_items INTEGER DEFAULT 0,
  assigned_lead_id UUID REFERENCES users(id),
  assigned_lead_name TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(deal_id, workstream)
);

-- ============================================================
-- TABLE: audit_log
-- PRD: Complete history of all state changes
-- ============================================================
CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID REFERENCES deals(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL, -- 'checklist_item', 'deal', 'risk', 'intake'
  entity_id UUID NOT NULL,
  action TEXT NOT NULL, -- 'status_change', 'created', 'updated', 'assigned'
  previous_state JSONB,
  new_state JSONB,
  changed_by UUID REFERENCES users(id),
  changed_by_name TEXT,
  reason TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_audit_deal ON audit_log(deal_id);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_time ON audit_log(created_at DESC);

-- ============================================================
-- TABLE: deal_milestones
-- Timeline markers calculated from close date
-- ============================================================
CREATE TABLE deal_milestones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  deal_id UUID NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  phase milestone_phase NOT NULL,
  label TEXT NOT NULL,
  target_date DATE NOT NULL,
  status TEXT DEFAULT 'upcoming', -- upcoming, active, complete, overdue
  items_due INTEGER DEFAULT 0,
  items_complete INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(deal_id, phase)
);

-- ============================================================
-- MATERIALIZED VIEW: Dashboard aggregation
-- Refresh on checklist status changes
-- ============================================================
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_deal_progress AS
SELECT
  d.id AS deal_id,
  d.name AS deal_name,
  d.stage,
  dci.workstream,
  COUNT(*) FILTER (WHERE dci.is_active) AS total_items,
  COUNT(*) FILTER (WHERE dci.status = 'complete' AND dci.is_active) AS complete,
  COUNT(*) FILTER (WHERE dci.status = 'in_progress' AND dci.is_active) AS in_progress,
  COUNT(*) FILTER (WHERE dci.status = 'blocked' AND dci.is_active) AS blocked,
  COUNT(*) FILTER (WHERE dci.status = 'not_started' AND dci.is_active) AS not_started,
  COUNT(*) FILTER (WHERE dci.status = 'not_applicable') AS not_applicable,
  ROUND(
    COUNT(*) FILTER (WHERE dci.status = 'complete' AND dci.is_active)::NUMERIC /
    NULLIF(COUNT(*) FILTER (WHERE dci.is_active), 0) * 100, 1
  ) AS completion_pct
FROM deals d
JOIN deal_checklist_items dci ON d.id = dci.deal_id
GROUP BY d.id, d.name, d.stage, dci.workstream;

CREATE UNIQUE INDEX idx_mv_progress ON mv_deal_progress(deal_id, workstream);

-- Function to refresh materialized view
CREATE OR REPLACE FUNCTION refresh_deal_progress()
RETURNS TRIGGER AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY mv_deal_progress;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger on checklist status changes
CREATE TRIGGER trg_refresh_progress
AFTER INSERT OR UPDATE OF status ON deal_checklist_items
FOR EACH STATEMENT
EXECUTE FUNCTION refresh_deal_progress();
