import { neon } from "@neondatabase/serverless";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

async function migrate() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error("❌ DATABASE_URL not set. Copy .env.example to .env and add your Neon connection string.");
    process.exit(1);
  }

  const sql = neon(databaseUrl);
  const migration = readFileSync(resolve(__dirname, "migration.sql"), "utf-8");

  console.log("🚀 Running migration against Neon...");

  try {
    // Split on semicolons but handle functions/triggers that contain semicolons
    // We run the whole thing as one statement block
    await sql(migration);
    console.log("✅ Migration complete.");
  } catch (err) {
    // If tables already exist, try dropping and recreating
    if (err.message?.includes("already exists")) {
      console.log("⚠️  Tables already exist. Run with --force to drop and recreate.");
      console.log("   Or connect to Neon console and drop tables manually.");
    } else {
      console.error("❌ Migration failed:", err.message);
    }
    process.exit(1);
  }
}

migrate();
