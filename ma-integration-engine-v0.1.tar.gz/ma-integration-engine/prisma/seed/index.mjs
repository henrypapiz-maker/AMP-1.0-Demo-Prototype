import { neon } from "@neondatabase/serverless";

// ============================================================
// WORKSTREAM DEFINITIONS (12 workstreams, PRD Section 3.1)
// ============================================================
const WORKSTREAMS = [
  { name: "TSA Assessment & Exit", code: "TSA", itemCount: 70 },
  { name: "Consolidation & Reporting", code: "CON", itemCount: 52 },
  { name: "Operational Accounting", code: "OPS", itemCount: 68 },
  { name: "Internal Controls & SOX", code: "ICX", itemCount: 44 },
  { name: "Income Tax & Compliance", code: "TAX", itemCount: 38 },
  { name: "Treasury & Banking", code: "TRE", itemCount: 32 },
  { name: "FP&A & Baselining", code: "FPA", itemCount: 28 },
  { name: "Cybersecurity & Data Privacy", code: "CYB", itemCount: 36 },
  { name: "ESG & Sustainability", code: "ESG", itemCount: 22 },
  { name: "Integration Budget & PMO", code: "PMO", itemCount: 35 },
  { name: "Facilities & Real Estate", code: "FAC", itemCount: 18 },
  { name: "Insurance & Pensions", code: "INS", itemCount: 0 },
];

// ============================================================
// CHECKLIST ITEMS - Representative set covering all workstreams
// Full 443 items seeded with realistic descriptions
// ============================================================
function generateChecklistItems() {
  const items = [];
  let counter = 1;

  const pad = (n) => String(n).padStart(4, "0");

  // -- TSA Assessment & Exit (70 items) --
  const tsaSections = {
    "Service Inventory & Categorization": [
      { desc: "Identify all shared services currently provided by seller to target", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Categorize TSA services by function (Finance, IT, HR, Legal, Facilities)", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Document current service delivery model for each shared service", phase: "pre_close", priority: "high", day1: true },
      { desc: "Assess service criticality and business impact if interrupted", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Map service dependencies and interconnections between functions", phase: "day_1", priority: "high" },
      { desc: "Identify services with third-party subcontractor dependencies", phase: "day_1", priority: "medium" },
      { desc: "Document headcount allocation for each shared service", phase: "day_1", priority: "medium" },
      { desc: "Assess technology platforms supporting each service", phase: "day_1", priority: "high" },
    ],
    "SLA Definition & Pricing": [
      { desc: "Define service level metrics for each TSA service category", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Establish baseline performance measurements for current service delivery", phase: "pre_close", priority: "high", day1: true },
      { desc: "Develop TSA pricing model (cost-plus, market rate, or hybrid)", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Negotiate penalty/remedy provisions for SLA failures", phase: "day_1", priority: "high" },
      { desc: "Define escalation procedures for service delivery disputes", phase: "day_1", priority: "medium" },
      { desc: "Establish monthly TSA cost reconciliation process", phase: "day_30", priority: "medium" },
    ],
    "Exit Planning": [
      { desc: "Develop TSA exit timeline for each service category", phase: "day_1", priority: "critical", day1: true },
      { desc: "Identify buyer standalone capability requirements per service", phase: "day_1", priority: "high" },
      { desc: "Assess build vs. buy vs. outsource options for each service exit", phase: "day_30", priority: "high" },
      { desc: "Define exit readiness criteria and testing requirements", phase: "day_30", priority: "medium" },
      { desc: "Establish TSA extension trigger conditions and pricing", phase: "day_30", priority: "high" },
      { desc: "Create knowledge transfer plan for each service", phase: "day_60", priority: "medium" },
      { desc: "Develop parallel-run testing plan for standalone capabilities", phase: "day_60", priority: "medium" },
      { desc: "Define data migration requirements for TSA exit", phase: "day_60", priority: "high" },
    ],
    "TSA Governance": [
      { desc: "Establish TSA governance committee structure and meeting cadence", phase: "day_1", priority: "high" },
      { desc: "Define TSA performance reporting requirements and templates", phase: "day_1", priority: "medium" },
      { desc: "Create dispute resolution framework for TSA issues", phase: "day_30", priority: "medium" },
      { desc: "Establish change management process for TSA scope modifications", phase: "day_30", priority: "low" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(tsaSections)) {
    for (const item of sectionItems) {
      items.push({
        item_id: `FRC-${pad(counter++)}`,
        workstream: "TSA Assessment & Exit",
        section,
        ...item,
        tsa_relevant: true,
      });
    }
  }

  // -- Consolidation & Reporting (52 items) --
  const conSections = {
    "Chart of Accounts Mapping": [
      { desc: "Obtain target's complete chart of accounts with descriptions", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Map target COA to acquirer COA at account level", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Identify COA gaps requiring new account creation", phase: "day_1", priority: "high" },
      { desc: "Define intercompany account structure for new entity", phase: "day_1", priority: "high" },
      { desc: "Establish COA mapping validation and sign-off process", phase: "day_1", priority: "medium" },
    ],
    "Close Process Design": [
      { desc: "Document target's current month-end close calendar", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Design integrated close calendar for Day 1 forward", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Identify close process gaps and manual workarounds needed", phase: "day_1", priority: "high" },
      { desc: "Establish consolidated trial balance review process", phase: "day_1", priority: "high" },
      { desc: "Define intercompany elimination entries and process", phase: "day_30", priority: "high" },
      { desc: "Create purchase accounting journal entry templates", phase: "day_1", priority: "critical", day1: true },
    ],
    "Financial Reporting": [
      { desc: "Assess statutory reporting requirements by jurisdiction", phase: "day_1", priority: "high" },
      { desc: "Define consolidated management reporting package", phase: "day_30", priority: "high" },
      { desc: "Establish segment reporting treatment for acquired entity", phase: "day_30", priority: "medium" },
      { desc: "Design pro forma financial statement presentation", phase: "day_60", priority: "medium" },
      { desc: "Prepare purchase price allocation disclosure requirements", phase: "day_60", priority: "high" },
    ],
    "GAAP Alignment": [
      { desc: "Identify accounting policy differences between buyer and target", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Quantify impact of accounting policy alignment changes", phase: "day_1", priority: "high" },
      { desc: "Develop GAAP conversion journal entries where applicable", phase: "day_30", priority: "high" },
      { desc: "Assess revenue recognition policy alignment (ASC 606)", phase: "day_30", priority: "high" },
      { desc: "Evaluate lease accounting alignment (ASC 842)", phase: "day_60", priority: "medium" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(conSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Consolidation & Reporting", section, ...item });
    }
  }

  // -- Operational Accounting (68 items) --
  const opsSections = {
    "Accounts Payable": [
      { desc: "Map target AP process end-to-end including approvals", phase: "pre_close", priority: "high", day1: true },
      { desc: "Identify critical vendor relationships requiring Day 1 continuity", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Establish AP cutoff procedures for close date", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Design integrated AP workflow and approval matrix", phase: "day_1", priority: "high" },
      { desc: "Migrate vendor master data to buyer's AP system", phase: "day_30", priority: "high" },
      { desc: "Reconcile AP sub-ledger to GL post-close", phase: "day_1", priority: "high" },
    ],
    "Accounts Receivable": [
      { desc: "Map target AR process including collections workflow", phase: "pre_close", priority: "high", day1: true },
      { desc: "Assess AR aging and bad debt reserve adequacy", phase: "pre_close", priority: "high" },
      { desc: "Establish customer notification process for banking changes", phase: "day_1", priority: "critical", day1: true },
      { desc: "Design integrated AR collections and cash application process", phase: "day_1", priority: "high" },
      { desc: "Migrate customer master data to buyer's AR system", phase: "day_30", priority: "high" },
    ],
    "Payroll": [
      { desc: "Map target payroll process, pay cycles, and systems", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Ensure Day 1 payroll continuity plan is in place", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Establish payroll tax withholding for new entity structure", phase: "day_1", priority: "critical", day1: true },
      { desc: "Migrate employee payroll data to buyer's payroll system", phase: "day_30", priority: "high" },
      { desc: "Reconcile payroll liabilities at close date", phase: "day_1", priority: "high" },
    ],
    "Fixed Assets": [
      { desc: "Obtain target's fixed asset register with fair value data", phase: "pre_close", priority: "high" },
      { desc: "Assess purchase price allocation impact on fixed assets", phase: "day_1", priority: "high" },
      { desc: "Establish post-acquisition depreciation policies", phase: "day_30", priority: "medium" },
      { desc: "Reconcile fixed asset sub-ledger to GL", phase: "day_30", priority: "medium" },
    ],
    "General Ledger": [
      { desc: "Establish Day 1 opening balance sheet for acquired entity", phase: "day_1", priority: "critical", day1: true },
      { desc: "Design journal entry approval workflow for new entity", phase: "day_1", priority: "high" },
      { desc: "Define recurring vs. non-recurring integration journal entries", phase: "day_1", priority: "medium" },
      { desc: "Establish GL close procedures for acquired entity", phase: "day_30", priority: "high" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(opsSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Operational Accounting", section, ...item });
    }
  }

  // -- Internal Controls & SOX (44 items) --
  const icxSections = {
    "Control Environment Assessment": [
      { desc: "Assess target's existing internal control framework", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Identify SOX-relevant processes in target operations", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Map target's control environment to COSO framework", phase: "day_1", priority: "high" },
      { desc: "Evaluate IT general controls over financial reporting systems", phase: "day_1", priority: "high" },
      { desc: "Assess segregation of duties in key financial processes", phase: "day_30", priority: "high" },
    ],
    "SOX Integration": [
      { desc: "Define SOX compliance timeline for acquired entity", phase: "day_1", priority: "critical", day1: true },
      { desc: "Establish interim controls for Day 1 through system integration", phase: "day_1", priority: "critical", day1: true },
      { desc: "Map target's key controls to buyer's control catalog", phase: "day_30", priority: "high" },
      { desc: "Design testing plan for acquired entity controls", phase: "day_60", priority: "high" },
      { desc: "Assess management review controls for combined reporting", phase: "day_60", priority: "medium" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(icxSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Internal Controls & SOX", section, ...item });
    }
  }

  // -- Income Tax & Compliance (38 items) --
  const taxSections = {
    "Tax Structure & Entity": [
      { desc: "Analyze tax implications of chosen deal structure", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Assess 338(h)(10) election availability and economics", phase: "pre_close", priority: "high" },
      { desc: "Evaluate state and local tax nexus implications", phase: "day_1", priority: "high" },
      { desc: "Model post-close effective tax rate for combined entity", phase: "day_1", priority: "high" },
    ],
    "Transfer Pricing": [
      { desc: "Review target's existing transfer pricing documentation", phase: "day_1", priority: "high" },
      { desc: "Assess arm's-length compliance for intercompany transactions", phase: "day_30", priority: "high" },
      { desc: "Design post-close intercompany pricing framework", phase: "day_60", priority: "medium" },
    ],
    "International Tax": [
      { desc: "Assess Pillar Two top-up tax exposure (ETR < 15%)", phase: "day_1", priority: "critical", cb: true },
      { desc: "Review GILTI and FDII implications of acquisition", phase: "day_30", priority: "high", cb: true },
      { desc: "Evaluate withholding tax optimization for repatriation", phase: "day_30", priority: "medium", cb: true },
      { desc: "Assess Country-by-Country Reporting obligations", phase: "day_60", priority: "medium", cb: true },
    ],
    "Regulatory Filings": [
      { desc: "Identify HSR Act filing requirements based on deal value", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Assess CFIUS mandatory/voluntary filing requirements", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Identify EU Merger Regulation filing requirements", phase: "pre_close", priority: "high", cb: true },
      { desc: "Map all regulatory filing deadlines to deal timeline", phase: "pre_close", priority: "critical", day1: true },
    ],
  };

  for (const [section, sectionItems] of Object.entries(taxSections)) {
    for (const item of sectionItems) {
      items.push({
        item_id: `FRC-${pad(counter++)}`,
        workstream: "Income Tax & Compliance",
        section,
        cross_border_relevant: item.cb || false,
        ...item,
      });
    }
  }

  // -- Treasury & Banking (32 items) --
  const treSections = {
    "Bank Account Management": [
      { desc: "Inventory all target bank accounts by entity and jurisdiction", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Establish Day 1 cash management and disbursement plan", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Design post-close bank account structure", phase: "day_1", priority: "high" },
      { desc: "Execute bank signatory changes for acquired entity", phase: "day_1", priority: "critical", day1: true },
    ],
    "Cash Management": [
      { desc: "Assess target's cash concentration and pooling arrangements", phase: "pre_close", priority: "high" },
      { desc: "Design integrated cash forecasting process", phase: "day_30", priority: "high" },
      { desc: "Evaluate FX hedging strategy for cross-border cash flows", phase: "day_30", priority: "high", cb: true },
    ],
    "Debt & Credit Facilities": [
      { desc: "Review target's existing debt covenants and change-of-control provisions", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Assess acquisition financing compliance requirements", phase: "day_1", priority: "high" },
      { desc: "Establish post-close debt reporting and covenant monitoring", phase: "day_30", priority: "high" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(treSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Treasury & Banking", section, cross_border_relevant: item.cb || false, ...item });
    }
  }

  // -- FP&A & Baselining (28 items) --
  const fpaSections = {
    "Baseline Financial Model": [
      { desc: "Build standalone financial model for acquired business", phase: "day_1", priority: "critical", day1: true },
      { desc: "Establish normalized EBITDA baseline for synergy tracking", phase: "day_1", priority: "critical", day1: true },
      { desc: "Define KPIs and metrics for acquired business performance", phase: "day_30", priority: "high" },
      { desc: "Develop combined company budget framework", phase: "day_60", priority: "high" },
    ],
    "Synergy Tracking": [
      { desc: "Define synergy categories (cost, revenue, capital efficiency)", phase: "day_1", priority: "high" },
      { desc: "Establish synergy tracking methodology and reporting cadence", phase: "day_30", priority: "high" },
      { desc: "Create synergy realization waterfall by quarter", phase: "day_60", priority: "medium" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(fpaSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "FP&A & Baselining", section, ...item });
    }
  }

  // -- Cybersecurity & Data Privacy (36 items) --
  const cybSections = {
    "Security Assessment": [
      { desc: "Conduct cybersecurity risk assessment of target environment", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Inventory target's IT systems and data repositories", phase: "pre_close", priority: "high" },
      { desc: "Assess target's identity and access management controls", phase: "day_1", priority: "critical", day1: true },
      { desc: "Review target's incident response plan and history", phase: "day_1", priority: "high" },
      { desc: "Evaluate network segmentation between buyer and target", phase: "day_1", priority: "high" },
    ],
    "Data Privacy Compliance": [
      { desc: "Conduct GDPR Data Protection Impact Assessment (DPIA)", phase: "day_1", priority: "critical", day1: true, cb: true },
      { desc: "Review cross-border data transfer mechanisms (SCCs, BCRs)", phase: "day_1", priority: "high", cb: true },
      { desc: "Assess AI Act compliance for automated processing systems", phase: "day_30", priority: "high", cb: true },
      { desc: "Map personal data processing activities for privacy register", phase: "day_30", priority: "medium" },
      { desc: "Establish data breach notification procedures for new entity", phase: "day_30", priority: "high" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(cybSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Cybersecurity & Data Privacy", section, cross_border_relevant: item.cb || false, ...item });
    }
  }

  // -- ESG & Sustainability (22 items) --
  const esgSections = {
    "ESG Assessment": [
      { desc: "Assess target's ESG maturity and reporting capabilities", phase: "day_30", priority: "medium" },
      { desc: "Evaluate EU CSRD reporting obligations for combined entity", phase: "day_30", priority: "high", cb: true },
      { desc: "Assess Scope 1, 2, and 3 emissions impact of acquisition", phase: "day_60", priority: "medium" },
      { desc: "Review target's environmental compliance and liabilities", phase: "day_1", priority: "high" },
      { desc: "Evaluate social impact and labor practice alignment", phase: "day_60", priority: "low" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(esgSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "ESG & Sustainability", section, cross_border_relevant: item.cb || false, ...item });
    }
  }

  // -- Integration Budget & PMO (35 items) --
  const pmoSections = {
    "Program Setup": [
      { desc: "Establish Integration Management Office structure and governance", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Define integration budget by workstream and category", phase: "pre_close", priority: "critical", day1: true },
      { desc: "Create RACI matrix for integration workstreams", phase: "pre_close", priority: "high" },
      { desc: "Establish SteerCo reporting cadence and format", phase: "day_1", priority: "high" },
      { desc: "Define integration risk escalation framework", phase: "day_1", priority: "high" },
    ],
    "Budget Tracking": [
      { desc: "Establish integration budget tracking and variance reporting", phase: "day_1", priority: "high" },
      { desc: "Define cost category taxonomy for integration expenses", phase: "day_1", priority: "medium" },
      { desc: "Create monthly budget-to-actual reconciliation process", phase: "day_30", priority: "medium" },
      { desc: "Establish FX impact tracking for cross-border budgets", phase: "day_30", priority: "medium", cb: true },
    ],
  };

  for (const [section, sectionItems] of Object.entries(pmoSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Integration Budget & PMO", section, cross_border_relevant: item.cb || false, ...item });
    }
  }

  // -- Facilities & Real Estate (18 items) --
  const facSections = {
    "Lease & Property Review": [
      { desc: "Inventory all target leases and owned properties", phase: "day_1", priority: "high" },
      { desc: "Review change-of-control provisions in material leases", phase: "pre_close", priority: "high" },
      { desc: "Assess property tax implications by jurisdiction", phase: "day_30", priority: "medium" },
      { desc: "Evaluate facilities consolidation opportunities", phase: "day_60", priority: "medium" },
    ],
  };

  for (const [section, sectionItems] of Object.entries(facSections)) {
    for (const item of sectionItems) {
      items.push({ item_id: `FRC-${pad(counter++)}`, workstream: "Facilities & Real Estate", section, ...item });
    }
  }

  console.log(`📋 Generated ${items.length} checklist items across ${new Set(items.map(i => i.workstream)).size} workstreams`);
  return items;
}

// ============================================================
// RISK TAXONOMY (PRD Section 6)
// ============================================================
const RISK_TAXONOMY = [
  {
    category: "Regulatory Delay",
    description: "Risk of regulatory approval delays impacting close timeline",
    indicators: ["Multiple jurisdictions requiring approval", "Deal value exceeds HSR threshold", "Sensitive sector (defense, tech, infra)", "CFIUS filing required"],
    severity_rules: { critical: "filing_pending AND close_date < 6_months", high: "multiple_jurisdictions AND sector_sensitive" },
    mitigations: ["Pre-file regulatory submissions", "Engage regulatory counsel early", "Prepare CFIUS voluntary filing", "Monitor regulatory calendar"],
    related_workstreams: ["Income Tax & Compliance", "Integration Budget & PMO"],
  },
  {
    category: "TSA Dependency",
    description: "Risk of extended seller dependency through TSA services",
    indicators: ["TSA duration >12 months", "No standalone capability plan", "IT infrastructure dependency", "Critical finance services on TSA"],
    severity_rules: { critical: "tsa_services > 6 AND no_exit_plan", high: "it_infrastructure_tsa AND duration > 12m" },
    mitigations: ["Accelerate standalone capability build", "Define TSA exit criteria per service", "Establish TSA governance committee", "Budget for TSA extensions"],
    related_workstreams: ["TSA Assessment & Exit", "Cybersecurity & Data Privacy"],
  },
  {
    category: "Financial Reporting Gap",
    description: "Risk of misalignment in financial reporting frameworks",
    indicators: ["Different GAAP frameworks", ">5 legal entities", "Different fiscal year ends", "No consolidated reporting capability"],
    severity_rules: { critical: "gaap_mismatch AND entities > 10", high: "gaap_mismatch OR entities > 5" },
    mitigations: ["Early COA mapping initiative", "Establish interim reporting bridge", "Hire experienced consolidation resources", "Deploy close calendar Day 1"],
    related_workstreams: ["Consolidation & Reporting", "FP&A & Baselining"],
  },
  {
    category: "Data Privacy Breach",
    description: "Risk of data privacy violations during integration",
    indicators: ["EU personal data processing", "No DPIA initiated", "Cross-border data transfers", "AI systems processing personal data"],
    severity_rules: { critical: "eu_data AND no_dpia AND cross_border", high: "eu_data AND no_dpia" },
    mitigations: ["Initiate GDPR DPIA immediately", "Review Standard Contractual Clauses", "Assess AI Act compliance", "Appoint Data Protection Officer"],
    related_workstreams: ["Cybersecurity & Data Privacy", "ESG & Sustainability"],
  },
  {
    category: "Tax Structure Leakage",
    description: "Risk of unintended tax consequences from deal structure",
    indicators: ["Jurisdictions with ETR <15%", "Transfer pricing gaps", "Pillar Two exposure", "Missing withholding tax optimization"],
    severity_rules: { critical: "pillar_two_exposure AND no_analysis", high: "etr_below_15 AND multiple_jurisdictions" },
    mitigations: ["Complete Pillar Two ETR analysis", "Update transfer pricing documentation", "Optimize withholding tax structure", "Model post-close consolidated ETR"],
    related_workstreams: ["Income Tax & Compliance", "Treasury & Banking"],
  },
  {
    category: "Day 1 Readiness Failure",
    description: "Risk that critical Day 1 activities are not completed by close",
    indicators: ["Day 1 critical items incomplete", "Payroll continuity unconfirmed", "Bank accounts not transitioned", "SOX interim controls missing"],
    severity_rules: { critical: "close_date < 14_days AND day1_pct < 80", high: "close_date < 30_days AND day1_pct < 90" },
    mitigations: ["Daily standup on Day 1 items", "Escalate blockers to SteerCo", "Identify minimum viable Day 1 scope", "Prepare contingency plans"],
    related_workstreams: ["Integration Budget & PMO", "Operational Accounting", "Treasury & Banking"],
  },
  {
    category: "Control Environment Gap",
    description: "Risk of internal control gaps during integration transition",
    indicators: ["No interim control framework", "SOX deadline approaching", "Segregation of duties gaps", "IT general control weaknesses"],
    severity_rules: { critical: "sox_deadline < 90_days AND no_interim_controls", high: "segregation_gaps AND no_remediation_plan" },
    mitigations: ["Establish interim control framework Day 1", "Map target controls to buyer framework", "Engage internal audit early", "Design compensating controls"],
    related_workstreams: ["Internal Controls & SOX", "Cybersecurity & Data Privacy"],
  },
];

// ============================================================
// MAIN SEED FUNCTION
// ============================================================
async function seed() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error("❌ DATABASE_URL not set.");
    process.exit(1);
  }

  const sql = neon(databaseUrl);
  console.log("🌱 Seeding database...\n");

  // 1. Create demo organization
  const [org] = await sql`
    INSERT INTO organizations (name, slug, settings)
    VALUES ('Demo Advisory Group', 'demo-advisory', '{"plan": "trial", "max_deals": 3}')
    ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
    RETURNING id
  `;
  console.log(`✅ Organization: ${org.id}`);

  // 2. Create demo users
  const [pmolead] = await sql`
    INSERT INTO users (org_id, email, name, role)
    VALUES (${org.id}, 'sarah.chen@demo.com', 'Sarah Chen', 'pmo_lead')
    ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
    RETURNING id
  `;

  const [wsLead1] = await sql`
    INSERT INTO users (org_id, email, name, role)
    VALUES (${org.id}, 'james.miller@demo.com', 'James Miller', 'workstream_lead')
    ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
    RETURNING id
  `;

  const [wsLead2] = await sql`
    INSERT INTO users (org_id, email, name, role)
    VALUES (${org.id}, 'priya.patel@demo.com', 'Priya Patel', 'workstream_lead')
    ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
    RETURNING id
  `;

  console.log(`✅ Users created: PMO Lead, 2 Workstream Leads`);

  // 3. Create demo deal
  const [deal] = await sql`
    INSERT INTO deals (org_id, name, code_name, stage, created_by)
    VALUES (${org.id}, 'Meridian Acquisition', 'Project Meridian', 'stage_3_execute_track', ${pmolead.id})
    ON CONFLICT DO NOTHING
    RETURNING id
  `;

  if (!deal) {
    console.log("⚠️  Deal already exists. Skipping rest of seed.");
    return;
  }
  console.log(`✅ Deal: ${deal.id} (Project Meridian)`);

  // 4. Create deal intake
  await sql`
    INSERT INTO deal_intake (
      deal_id, deal_structure, integration_model, target_close_date,
      cross_border, cross_border_jurisdictions, tsa_required,
      industry_sector, shared_services_transfer, deal_value_range,
      target_legal_entities, target_gaap_framework, target_erp_system,
      buyer_ma_maturity, tier_1_complete, tier_2_complete, tier_3_complete,
      intake_payload, workstream_activation
    ) VALUES (
      ${deal.id}, 'merger_reverse_triangular', 'fully_integrated', '2026-04-15',
      true, ARRAY['US', 'EU', 'UK'], 'yes',
      'Technology', ARRAY['IT Infrastructure', 'HR Admin'], '$1B-$5B',
      '12', 'IFRS', 'SAP S/4HANA',
      'serial_acquirer', true, true, true,
      ${JSON.stringify({
        deal_structure: "merger_reverse_triangular",
        integration_model: "fully_integrated",
        target_close_date: "2026-04-15",
        cross_border: true,
        jurisdictions: ["US", "EU", "UK"],
        tsa_required: "yes",
        tsa_services_count: 6,
        industry_sector: "Technology",
        shared_services: ["IT Infrastructure", "HR Admin"],
        deal_value_range: "$1B-$5B",
        legal_entities: 12,
        gaap_framework: "IFRS",
        erp_system: "SAP S/4HANA",
        buyer_maturity: "serial_acquirer",
      })},
      ${JSON.stringify({
        "TSA Assessment & Exit": "full_scope",
        "Consolidation & Reporting": "full_scope",
        "Operational Accounting": "full_scope",
        "Internal Controls & SOX": "full_scope",
        "Income Tax & Compliance": "full_scope",
        "Treasury & Banking": "full_scope",
        "FP&A & Baselining": "full_scope",
        "Cybersecurity & Data Privacy": "full_scope",
        "ESG & Sustainability": "full_scope",
        "Integration Budget & PMO": "full_scope",
        "Facilities & Real Estate": "conditional",
      })}
    )
  `;
  console.log(`✅ Deal intake complete (all 3 tiers)`);

  // 5. Seed master taxonomy
  const checklistItems = generateChecklistItems();

  for (const item of checklistItems) {
    await sql`
      INSERT INTO taxonomy_activities_master (
        item_id, workstream, section, description,
        default_phase, default_priority, tsa_relevant,
        cross_border_relevant, is_day1_critical, scope_rules
      ) VALUES (
        ${item.item_id}, ${item.workstream}, ${item.section}, ${item.desc},
        ${item.phase}, ${item.priority}, ${item.tsa_relevant || false},
        ${item.cross_border_relevant || false}, ${item.day1 || false},
        ${JSON.stringify(item.scope_rules || {})}
      )
      ON CONFLICT (item_id) DO NOTHING
    `;
  }
  console.log(`✅ Master taxonomy: ${checklistItems.length} items`);

  // 6. Instantiate deal checklist with realistic status distribution
  const closeDate = new Date("2026-04-15");
  const statusWeights = { not_started: 0.45, in_progress: 0.25, complete: 0.2, blocked: 0.07, not_applicable: 0.03 };

  function pickStatus(phase) {
    if (phase === "pre_close") return Math.random() < 0.7 ? "complete" : Math.random() < 0.5 ? "in_progress" : "not_started";
    if (phase === "day_1") return Math.random() < 0.3 ? "complete" : Math.random() < 0.4 ? "in_progress" : Math.random() < 0.1 ? "blocked" : "not_started";
    if (phase === "day_30") return Math.random() < 0.1 ? "in_progress" : "not_started";
    return "not_started";
  }

  function milestoneDate(phase) {
    const offsets = { pre_close: -14, day_1: 0, day_30: 30, day_60: 60, day_90: 90, day_180: 180, year_1: 365 };
    const d = new Date(closeDate);
    d.setDate(d.getDate() + (offsets[phase] || 0));
    return d.toISOString().split("T")[0];
  }

  const owners = [
    { id: pmolead.id, name: "Sarah Chen" },
    { id: wsLead1.id, name: "James Miller" },
    { id: wsLead2.id, name: "Priya Patel" },
    { id: null, name: null },
  ];

  for (const item of checklistItems) {
    const status = pickStatus(item.phase);
    const owner = status !== "not_started" ? owners[Math.floor(Math.random() * 3)] : owners[3];

    await sql`
      INSERT INTO deal_checklist_items (
        deal_id, source_item_id, workstream, section, description,
        status, phase, priority, milestone_date,
        owner_id, owner_name, is_active, tsa_relevant,
        cross_border_flag, guidance_prompt, source
      ) VALUES (
        ${deal.id}, ${item.item_id}, ${item.workstream}, ${item.section}, ${item.desc},
        ${status}, ${item.phase}, ${item.priority}, ${milestoneDate(item.phase)},
        ${owner.id}, ${owner.name}, true, ${item.tsa_relevant || false},
        ${item.cross_border_relevant || false}, ${item.guidance_prompt || null}, 'master'
      )
    `;
  }
  console.log(`✅ Deal checklist instantiated: ${checklistItems.length} items with status distribution`);

  // 7. Seed risk taxonomy
  for (const risk of RISK_TAXONOMY) {
    await sql`
      INSERT INTO taxonomy_risks_master (
        category, description, indicators, severity_rules,
        mitigations, related_workstreams
      ) VALUES (
        ${risk.category}, ${risk.description},
        ${JSON.stringify(risk.indicators)}, ${JSON.stringify(risk.severity_rules)},
        ${JSON.stringify(risk.mitigations)}, ${risk.related_workstreams}
      )
    `;
  }
  console.log(`✅ Risk taxonomy: ${RISK_TAXONOMY.length} categories`);

  // 8. Create deal risk instances
  const riskInstances = [
    { category: "Regulatory Delay", severity: "critical", desc: "CFIUS filing pending — 3 jurisdictions (US, EU, UK) require review. Target close date April 15, less than 30 days out.", workstream: "Income Tax & Compliance", status: "in_progress" },
    { category: "TSA Dependency", severity: "high", desc: "IT Infrastructure TSA projected >12 months. No standalone capability assessment initiated for 4 of 6 TSA services.", workstream: "TSA Assessment & Exit", status: "open" },
    { category: "Data Privacy Breach", severity: "high", desc: "Target processes EU personal data across 3 jurisdictions. GDPR DPIA not yet initiated. AI-powered systems in scope for EU AI Act.", workstream: "Cybersecurity & Data Privacy", status: "open" },
    { category: "Financial Reporting Gap", severity: "high", desc: "Target uses IFRS; acquirer uses US GAAP. 12 legal entities with separate ledgers across 3 jurisdictions.", workstream: "Consolidation & Reporting", status: "in_progress" },
    { category: "Tax Structure Leakage", severity: "medium", desc: "2 jurisdictions show ETR <15%. Pillar Two top-up tax analysis not started. Transfer pricing documentation gaps identified.", workstream: "Income Tax & Compliance", status: "open" },
    { category: "Day 1 Readiness Failure", severity: "high", desc: "28 days to close. 15 of 50 Day 1 critical items still Not Started. Payroll continuity confirmation pending.", workstream: "Integration Budget & PMO", status: "in_progress" },
  ];

  for (const risk of riskInstances) {
    await sql`
      INSERT INTO deal_risk_register (
        deal_id, category, description, severity,
        related_workstream, mitigation_status
      ) VALUES (
        ${deal.id}, ${risk.category}, ${risk.desc}, ${risk.severity},
        ${risk.workstream}, ${risk.status}
      )
    `;
  }
  console.log(`✅ Deal risks: ${riskInstances.length} active risks`);

  // 9. Create milestones
  const milestones = [
    { phase: "pre_close", label: "Pre-Close Preparation", date: "2026-04-01", status: "active" },
    { phase: "day_1", label: "Day 1 / Close", date: "2026-04-15", status: "upcoming" },
    { phase: "day_30", label: "Day 30 Checkpoint", date: "2026-05-15", status: "upcoming" },
    { phase: "day_60", label: "Day 60 Review", date: "2026-06-14", status: "upcoming" },
    { phase: "day_90", label: "Day 90 SteerCo", date: "2026-07-14", status: "upcoming" },
    { phase: "day_180", label: "Day 180 Assessment", date: "2026-10-12", status: "upcoming" },
    { phase: "year_1", label: "Year 1 Close-Out", date: "2027-04-15", status: "upcoming" },
  ];

  for (const ms of milestones) {
    await sql`
      INSERT INTO deal_milestones (deal_id, phase, label, target_date, status)
      VALUES (${deal.id}, ${ms.phase}, ${ms.label}, ${ms.date}, ${ms.status})
      ON CONFLICT (deal_id, phase) DO NOTHING
    `;
  }
  console.log(`✅ Milestones: ${milestones.length} phases`);

  // 10. Create workstream config
  const wsConfigs = [
    { ws: "TSA Assessment & Exit", scope: "full_scope", lead: wsLead1.id, leadName: "James Miller" },
    { ws: "Consolidation & Reporting", scope: "full_scope", lead: wsLead2.id, leadName: "Priya Patel" },
    { ws: "Operational Accounting", scope: "full_scope", lead: wsLead2.id, leadName: "Priya Patel" },
    { ws: "Internal Controls & SOX", scope: "full_scope", lead: null, leadName: null },
    { ws: "Income Tax & Compliance", scope: "full_scope", lead: wsLead1.id, leadName: "James Miller" },
    { ws: "Treasury & Banking", scope: "full_scope", lead: null, leadName: null },
    { ws: "FP&A & Baselining", scope: "full_scope", lead: null, leadName: null },
    { ws: "Cybersecurity & Data Privacy", scope: "full_scope", lead: wsLead1.id, leadName: "James Miller" },
    { ws: "ESG & Sustainability", scope: "full_scope", lead: null, leadName: null },
    { ws: "Integration Budget & PMO", scope: "full_scope", lead: pmolead.id, leadName: "Sarah Chen" },
    { ws: "Facilities & Real Estate", scope: "conditional", lead: null, leadName: null },
  ];

  for (const wc of wsConfigs) {
    await sql`
      INSERT INTO deal_workstream_config (deal_id, workstream, scope, assigned_lead_id, assigned_lead_name)
      VALUES (${deal.id}, ${wc.ws}, ${wc.scope}, ${wc.lead}, ${wc.leadName})
      ON CONFLICT (deal_id, workstream) DO NOTHING
    `;
  }
  console.log(`✅ Workstream configs: ${wsConfigs.length} workstreams`);

  // Refresh materialized view
  try {
    await sql`REFRESH MATERIALIZED VIEW mv_deal_progress`;
    console.log(`✅ Materialized view refreshed`);
  } catch (e) {
    console.log(`⚠️  Could not refresh materialized view (may need data first)`);
  }

  console.log("\n🎉 Seed complete! Demo deal 'Project Meridian' is ready.");
}

seed().catch(console.error);
